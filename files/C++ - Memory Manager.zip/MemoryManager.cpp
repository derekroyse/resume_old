/************************************************
MemoryManager.cpp -- Allocates and manages storage dynamically.
Author: Derek Royse
Usage: Manage memory.
*************************************************/
#include <iostream>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <tgmath.h>
#include "list.h"

using namespace std;

void printMenu(bool& pmFit, bool& pmCompact);

int main()
{
    bool fitChoice = 0;
    bool compactChoice = 0;
    int jobNumber;
    double jobLength;   // Length in words.
    double k;           // Length in blocks.
    int freeSpace;      // -1 = not found
    ifstream jobList ("jobs.txt");

    // Initialize lists.
    AvailableList available(0, 1024);
    ReservedList reserved(0, 0, 0);

    // Retrieve initial values.
    jobList >> jobNumber;
    jobList >> jobLength;

    // Print options menu.
    printMenu(fitChoice, compactChoice);

    // Handle every job until there are no jobs left.
    while (jobList)
    {
        // Convert word value to kiloword value (rounded up).
        k = jobLength/1024;
        k = ceil(k);

        // Print out header and available/reserved lists BEFORE operation.
        cout << "Job #: " << jobNumber << "  " << "Job Length: " << jobLength
             << " words: " << k << " blocks." << endl;
        cout << "Before: " << endl;
        available.print();
        reserved.print();

        // Handle job removal.
        if (jobLength == 0)
        {
            available.insert(jobNumber, reserved);
            reserved.remove(jobNumber);
        }
        // Handle job addition.
        else
        {
            // Determine where to place the new job in memory based on the fit algorithm chosen.
            if (fitChoice == 1)
                freeSpace = available.searchWorst(k);
            else
                freeSpace = available.searchFirst(k);

            // If a suitable spot is not found.
            if (freeSpace == -1)
            {
                cout << "______________________________________________________" << endl;
                cout << "-                                                    -" << endl;
                cout << "-    Not enough free space in available memory.      -" << endl;
                cout << "-                                                    -" << endl;
                cout << "------------------------------------------------------" << endl;

                // If compaction/coalescence is enabled, attempt it here.
                if  (compactChoice == 1)
                {
                    cout << "______________________________________________________" << endl;
                    cout << "-                                                    -" << endl;
                    cout << "-    Attempting to coalesce and compact memory.      -" << endl;
                    cout << "-                                                    -" << endl;
                    cout << "------------------------------------------------------" << endl;
                    available.compactCoalesce(reserved);

                    // Reattempt to place job.
                    // Search again.
                    if (fitChoice == 1)
                        freeSpace = available.searchWorst(k);
                    else
                        freeSpace = available.searchFirst(k);

                    // If a space is found, place the job there. Otherwise return to the main loop.
                    if (freeSpace != -1)
                    {
                        available.remove(k, freeSpace);
                        reserved.insert(jobNumber, freeSpace, k);
                    }
                    else
                    {
                        cout << "______________________________________________________" << endl;
                        cout << "-                                                    -" << endl;
                        cout << "-             Compact/Coalesce failed.               -" << endl;
                        cout << "-              Moving to next job...                 -" << endl;
                        cout << "------------------------------------------------------" << endl;
                    }
                }
            }
            // If a suitable spot is found.
            else
            {
                available.remove(k, freeSpace);
                reserved.insert(jobNumber, freeSpace, k);
            }
        }

        // Print out available and reserved lists AFTER operation.
        cout << "After: " << endl;
        available.print();
        reserved.print();
        cout << "----------------------------------------------------------------------------" << endl << endl;
        reserved.printVisual();
        cout << endl;

        // Get a new job and its length.
        jobList >> jobNumber;
        jobList >> jobLength;

        system("pause");
        system("cls");
    }

    return 0;
}

// Output a menu to allow users to change fit strategy and compaction options.
void printMenu(bool& pmFit, bool& pmCompact)
{
    char menuChoice = 0;
    bool menuFitChoice = 0;
    bool menuCompactChoice = 0;

    while (menuChoice != 'q' || menuChoice != 'Q')
    {
        cout << "Welcome to the memory manager!" << endl << "Enter one of the choices below..." << endl;
        cout << "1. Change fit algorithm." << endl << "2. Enable/Disable compaction and coalescence." << endl;
        cout << "Q = Quit menu and start memory management." << endl;

        cin >> menuChoice;

        if (menuChoice == '1')
        {
            cout << "Enter 0 to choose 'First Fit' or 1 to choose 'Worst Fit': " << endl;
            cout << "Current choice: " << pmFit << endl;
            cin >> menuFitChoice;

            if (menuFitChoice == 0)
            {
                cout << "You have successfully chosen 'First Fit'. Returning to main menu..." << endl;
                pmFit = 0;
            }
            else if (menuFitChoice == 1)
            {
                cout << "You have successfully chosen 'Worst Fit'. Returning to main menu..." << endl;
                pmFit = 1;
            }
            else
                cout << "Invalid choice. Returning to main menu." << endl;
        }
        else if (menuChoice == '2')
        {
            cout << "Enter 0 to disable compaction and coalescence or 1 enable them: " << endl;
            cout << "Current choice: " << pmCompact << endl;
            cin >> menuCompactChoice;

            if (menuCompactChoice == 0)
            {
                cout << "You have successfully disabled compaction and coalescence. Returning to main menu..." << endl;
                pmCompact = 0;
            }
            else if (menuCompactChoice == 1)
            {
                cout << "You have successfully enabled compaction and coalescence. Returning to main menu..." << endl;
                pmCompact = 1;
            }
            else
                cout << "Invalid choice. Returning to main menu." << endl;

        }
        else if (menuChoice == 'Q' || menuChoice == 'q')
        {
            cout << "Exiting menu and starting main program..." << endl;
            return;
        }
        else
            cout << "Invalid choice. Returning to main menu." << endl;

        system("pause");
        system("cls");
    }

    return;
}
