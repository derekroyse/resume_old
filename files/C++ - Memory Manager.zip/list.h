/************************************************
List.h -- Program implements ReservedList and AvailableList classes.
Author: Derek Royse
Usage: Create, view, and modify ReservedList and AvailableList objects.
*************************************************/
#ifndef LIST_H
#define LIST_H
#include <iostream>

using namespace std;

struct node
{
    int job;
    int address;
    int length;
    node * next;
};

/************************************************
ReservedList class

Member functions:
    ReservedList()      -- Creates and initializes a new list.
    getHead()           -- Returns the list's head pointer.
    findLength()        -- Find the length of a specified job.
    findAddress()       -- Find the address of a specified job.
    insert()            -- Insert an item into the list.
    remove()            -- Remove an item from the list.
    print()             -- Print the list.
    printVisual()       -- Prints a visual representation of available
                        -- and reserved memory.
*************************************************/
class ReservedList
{
    private:
        node * head;
    public:
        ReservedList(int inJob, int inAddress, int inLength)
        {
            // Initialization
            node * insertNode = new node;

            insertNode -> job = inJob;
            insertNode -> address = inAddress;
            insertNode -> length = inLength;
            insertNode -> next = NULL;

            head = NULL;
        }



        node* getHead()
        {
            return head;
        }



        int findLength(int inJob)
        {
            node * temp = head;
            while (temp != NULL)
            {
            if (temp -> job == inJob)
                {
                    return temp -> length;
                }
                temp = temp -> next;
            }
            return -1;

        }



        int findAddress(int inJob)
        {
            node * temp = head;
            while (temp != NULL)
            {
            if (temp -> job == inJob)
                {
                    return temp -> address;
                }
                temp = temp -> next;
            }
            return -1;
        }



        void remove(int jobNumber)
        {
            node* current = head;
            node* temp;

            if (findLength(jobNumber) == -1)
                return;

            while (current != NULL)
            {
                // If removing the head as the only existing node.
                if (current == head && current -> next == NULL && current -> job == jobNumber)
                {
                    head = NULL;
                    delete current;
                    return;
                }
                // If removing the tail.
                else if (current -> next -> next == NULL && current -> next -> job == jobNumber)
                {

                    temp = current -> next;
                    current -> next = NULL;
                    delete temp;
                    return;
                }
                // If removing the head.
                else if (current == head && current -> job == jobNumber)
                {
                    head = current -> next;
                    delete current;
                    return;
                }
                // If removing an interior node.
                else if (current -> next -> job == jobNumber)
                {
                    temp = current -> next;
                    current -> next = current -> next -> next;
                    delete temp;
                    return;
                }
                current = current -> next;
            }
        }



        void insert(int inJob, int inAddress, int inLength)
        {
            node* newNode = new node;
            node* current = head;
            newNode -> job = inJob;
            newNode -> address = inAddress;
            newNode -> length = inLength;
            newNode -> next = NULL;

            // If head = NULL, create a new head.
            if(head == NULL)
            {
                head = newNode;
                return;
            }
            // Otherwise search for the right spot and insert the new node.
            while (current != NULL)
            {
                //If the new node is the tail.
                if (current -> next == NULL && inAddress > current -> address)
                {
                    current -> next = newNode;
                    newNode -> next = NULL;
                    return;
                }
                // If the new node is between two existing values.
                else if (inAddress > current -> address && inAddress < current -> next -> address)
                {
                    newNode -> next = current -> next;
                    current -> next = newNode;
                    return;
                }
                // If the new node is the new head.
                else if (inAddress < current -> address && current == head)
                {
                    newNode -> next = current;
                    head = newNode;
                    return;
                }
                current = current -> next;
            }
        }



        void print()
        {
            cout << "Reserved: " << endl;
            cout << "Job #    Address  Length" << endl;
            node * temp = head;
            while (temp != NULL)
            {
                printf("%-9i%-9i%-9i", temp -> job, temp -> address, temp-> length);
                cout << endl;
                temp = temp -> next;
            }
            cout << endl;
        }



        void printVisual()
        {
            node* temp = head;
            int visualArray[1024] = {0};

            cout << " Visual Representation of memory." << endl << " Ones represent occupied space while zeros represent free space." << endl;

            while (temp != NULL)
            {
                for (int i = 0; i < 1024; i++)
                {
                    if (i >= temp -> address && i <= temp -> address + temp -> length - 1)
                        visualArray[i] = 1;
                }
                temp = temp -> next;
            }
            cout << "|----------------------------------------------------------------|" << endl << "|";
            for (int j = 1; j < 1025; j++)
            {
                if (j % 64 == 0)
                    cout << visualArray[j-1] << "|" << endl << "|";
                else
                    cout << visualArray[j-1];
            }
            cout << "----------------------------------------------------------------|" << endl;
        }

};

/************************************************
AvailableList class

Member functions:
    AvailableList()     -- Creates and initializes a new list.
    getHead()           -- Returns the list's head pointer.
    insert()            -- Insert an item into the list.
    remove()            -- Remove an item from the list.
    print()             -- Print the list.
    searchFirst()       -- Search the available list for a free space based on first fit strategy.
    searchWorst()       -- Search the available list for a free space based on worst fit strategy.
    compactCoalesce()  -- Attempts to combine all free blocks into one and move this block to the end
                        -- of the available list.

*************************************************/

class AvailableList
{
    private:
        node * head;
    public:
        AvailableList(int inAddress, int inLength)
        {
            node * insertNode = new node;

            insertNode -> address = inAddress;
            insertNode -> length = inLength;
            insertNode -> next = NULL;

            head = insertNode;
        }

        node* getHead()
        {
            return head;
        }



        // Insert a new block of free memory (when removing an old job)
        void insert(int inJob, ReservedList reserved)
        {
            int removalAddress;
            int removalLength;

            // Retrieve job data from the reserved list.
            removalAddress = reserved.findAddress(inJob);
            removalLength = reserved.findLength(inJob);

            // Temporary available node initialization.
            node* newNode = new node;
            node* current = head;
            node* temp;
            newNode -> next = NULL;
            newNode -> address = removalAddress;
            newNode -> length = removalLength;

            // If attempting to remove a job that doesn't exist, display an error message.
            if (removalLength == -1)
            {
                cout << "______________________________________________________" << endl;
                cout << "-                                                    -" << endl;
                cout << "-               Job not found...                     -" << endl;
                cout << "-                                                    -" << endl;
                cout << "------------------------------------------------------" << endl;
                return;
            }

            // Loop through the available list.
            while (current != NULL)
            {
                // If we are dealing with a new head.
                if (removalAddress < current -> address && current == head)
                {
                    // Remove empty node when creating a new head for an empty list.
                    if (current -> length == 0)
                    {
                        delete current;
                    }
                    else
                        newNode -> next = current;

                    head = newNode;
                    return;
                }
                // If we are dealing with the the entire set of memory.
                else if (removalAddress == 0 && removalLength == 1024)
                {
                    current -> next = NULL;
                    head = current;
                    return;
                }
                // If we are dealing with the tail.
                else if (current -> next == NULL && removalAddress > current -> address)
                {
                    newNode -> next = NULL;
                    current -> next = newNode;
                    return;
                }
                // If we are dealing with an interior block.
                else if (current -> address < removalAddress && current -> next -> address > removalAddress)
                {
                    newNode -> next = current -> next;
                    current -> next = newNode;
                    return;
                }
                current = current -> next;
            }
        }



        // Remove available memory (when adding a new job)
        void remove(int inLength, int inAddress)
        {
            // Temporary availabe node initialization.
            node* current = head;
            node* temp;

            node* newNode = new node;
            newNode -> length = 0;
            newNode -> address = 0;
            newNode -> next = NULL;

            // Loop through the available list.
            while (current != NULL)
            {
                // Removing free space from head as the only existing node.
                if (current == head && current -> next == NULL)
                {
                    // If empty space is filled.
                    if (inLength == current -> length)
                    {
                        current -> address = 1024;
                        current -> length = 0;
                    }
                    // If empty space remains.
                    else
                    {
                        current -> address = current -> address + inLength;
                        current -> length = current -> length - inLength;
                    }
                    return;
                }
                // Removing free space from head.
                else if (current == head && current -> address == inAddress)
                {
                    // If empty space is filled.
                    if (inLength >= current -> length)
                    {
                        head = current -> next;
                        delete current;
                    }
                    // If empty space remains.
                    else
                    {
                        current -> address = current -> address + inLength;
                        current -> length = current -> length - inLength;
                    }
                    return;
                }
                // Removing space from interior.
                else if (current -> address == inAddress && current -> next != NULL)
                {
                    // If empty space is filled.
                    if (inLength >= current -> length)
                    {
                        temp = current -> next;
                        current -> next = current -> next -> next;
                        current = temp;
                        delete current;
                    }
                    // If empty space remains.
                    else
                    {
                        current -> address = current -> address + inLength;
                        current -> length = current -> length - inLength;
                    }
                    return;
                }
                // Removing free space from tail.
                else if (current -> next == NULL)
                {
                    // If empty space is filled.
                    if (inLength >= current -> length)
                    {
                        temp = current -> next;
                        current -> next = NULL;
                        current = temp;
                        delete current;
                    }
                    // If empty space remains.
                    else
                    {
                        current -> address = current -> address + inLength;
                        current -> length = current -> length - inLength;
                    }
                    return;
                }
            current = current -> next;
            }
            return;
        }



        void print()
        {
            cout << "Available: " << endl;
            cout << "Address     Length" << endl;
            node * temp = head;
            while (temp != NULL)
            {
                printf("%-12i%-12i%", temp -> address, temp-> length);
                cout << endl;
                temp = temp -> next;
            }
            cout << endl;
        }



        // Find and return the first available space large enough for the job.
        int searchFirst(int jobLength)
        {
            node * temp = head;
            while (temp != NULL)
            {
                if (temp -> length >= jobLength)
                    {
                        return temp -> address;
                    }
                temp = temp -> next;
            }
            return -1;
        }



        // Find and return the address of the block in memory that will
        // result in creating the largest block of free memory after the
        // job is added. (The biggest block, basically)
        int searchWorst(int jobLength)
        {
            int largest = -1;
            int newAddress = -1;
            int n = 0;
            node * temp = head;

            while (temp != NULL)
            {
                // If the difference between the size of the node and the size of the job is greater
                // than the previous largest value, update the value and the address.
                if (temp -> length >= jobLength)
                    {
                    if (temp -> length - jobLength > largest)
                        {
                            largest = temp -> length - jobLength;
                            newAddress = temp -> address;
                        }
                    }
                temp = temp -> next;
            }
            return newAddress;
        }



        void compactCoalesce(ReservedList reserved)
        {
            node* newNode = new node;
            node* current = reserved.getHead();
            node* currentA = head;
            node* temp;

            int a = 0;
            int b = 0;
            int sum = 0;

            // Traverse the reserved list and move all nodes to the front of the list.
            while (current != NULL)
            {
                current -> address = a;
                a = current -> address + current -> length;

                if (current -> next == NULL)
                {
                    b = current -> address + current -> length;
                }
                    current = current -> next;
            }

            // Traverse the available list, removing nodes and adding their memory
            // values to one large pool that begins after the last reserved address.
            while (currentA != NULL)
            {
                sum = sum + currentA -> length;
                temp = currentA -> next;
                delete currentA;
                currentA = temp;
            }

            newNode -> job = 0;
            newNode -> address = b;
            newNode -> length = sum;
            newNode -> next = NULL;
            head = newNode;
        }
};


#endif
