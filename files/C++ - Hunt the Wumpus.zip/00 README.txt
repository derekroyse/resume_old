WumpusFinal 		= Standard text-game style, no map.
WumpusFinal - Test 	= Testing game with map, totally cheating.