/************************************************
WumpusFinal - Hunt the Wumpus text-based game.
            - Standard version.

Author: Derek Royse & Ioan Istrate

Purpose: A recreation of the classic Hunt the Wumpus game.
*************************************************/
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include "wumpus.h"

using namespace std;

/*********************************************************************
Game begins here.
**********************************************************************/
void BoardTest();

int main()
{
    BoardTest();
    return 0;
}

void BoardTest()
{
    char input = 'q';
    char replay = 'y';
    bool sentinel = 0;
    srand(time(NULL));
    Board test;
    Player player1;
    Wumpus wumpus1;

    // Creation of start, end, and help screens.
    ifstream infile1("wumpusStart.txt");
    infile1.unsetf(ios_base::skipws);
    Screen startScreen(infile1);
    ifstream infile2("wumpusEnd.txt");
    infile2.unsetf(ios_base::skipws);
    Screen endScreen(infile2);
    ifstream infile3("wumpusHelp.txt");
    infile3.unsetf(ios_base::skipws);
    Screen helpScreen(infile3);

    // Allow the player to move until a death event occurs.
    while (replay == 'Y' || replay == 'y')
    {
        //Display welcome screen;
        startScreen.print();
        system("pause");
        system("cls");
        helpScreen.print();
        system("pause");
        system("cls");

        //Generate a new board and randomize locations.
        test.generateBoard();
        test.populateBoard();
        player1.updateLocation(test);
        sentinel = 0;

        // While the player is alive, ask for movement/shooting input.
        while (sentinel == 0)
        {
            player1.updateLocation(test);
            wumpus1.updateLocation(test);
            input = 'q';

            // Display input prompt until the player enters valid input.
            while (input != 'W' && input != 'w' && input != 'E' && input != 'e' &&
                   input != 'N' && input != 'n' && input != 'S' && input != 's' &&
                   input != 'A' && input != 'a')
            {
                player1.displayWarnings(test);
                player1.displayActions();
                cout << "Please enter a direction to move or 'A' to shoot an arrow. ";
                    cin >> input;

                // Print error message if user enters invalid input.
                if (input != 'W' && input != 'w' && input != 'E' && input != 'e' &&
                    input != 'N' && input != 'n' && input != 'S' && input != 's' &&
                    input != 'A' && input != 'a')
                {
                    cout << "You cannot move in that direction (there is a wall in your way." << endl
                         << "Please enter one of the above directions to move or 'A' to shoot." << endl;
                }
                else if (input == 'A' || input == 'a')
                {
                    if (player1.getArrows() > 0)
                    {
                        cout << "In which direction would you like to shoot? (W) (E) (N) (S)" << endl;
                            cin >> input;
                        sentinel = player1.shoot(input, test);
                        if (sentinel == 0)
                        {
                            wumpus1.move(test);
                        }

                    }
                    else
                        cout << "You don't have any arrows!" << endl;
                }
                else
                  sentinel = player1.move(input, test);
                cout << endl;
            }

            // Refresh board.
            system("pause");

        }

        // Trigguers upon game end.
        system("cls");
        endScreen.print();
        cout << "Press 'Y' to play again or any other key to quit: ";
            cin >> replay;
        system("cls");
    }
}

