/************************************************
object.h    - Entity related classes header file.
            - Object (base class)
            - Player
            - Enemy
            - Star
            - Starbase

Author: Derek Royse & Andy Pritt

Purpose: These classes store and print locational data.
*************************************************/
#ifndef OBJECT_H
#define OBJECT_H
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

/************************************************
Object class

Member functions:
    getQuadrantX()      Returns the object's quadrantX value.
    getQuadrantY()      Returns the object's quadrantY value.
    getSectorX()        Returns the object's sectorX value.
    getSectorY()        Returns the object's sectorY value.
    setQuadrantX()      Sets the object's quadrantX vale to
                        an integer value passed to the method.
    setQuadrantY()      Sets the object's quadrantX vale to
                        an integer value passed to the method.
    setSectorX()        Sets the object's quadrantX vale to
                        an integer value passed to the method.
    setSectorY()        Sets the object's quadrantX vale to
                        an integer value passed to the method.
*************************************************/
class Object
{
protected:
    int sectorX;
    int sectorY;
    int quadrantX;
    int quadrantY;
public:
    int getQuadrantX()
    {
        return quadrantX;
    }

    int getQuadrantY()
    {
        return quadrantY;
    }

    int getSectorX()
    {
        return sectorX;
    }

    int getSectorY()
    {
        return sectorY;
    }

    void setQuadrantX(int input)
    {
        quadrantX = input;
    }

    void setQuadrantY(int input)
    {
        quadrantY = input;
    }

    void setSectorX(int input)
    {
        sectorX = input;
    }

    void setSectorY(int input)
    {
        sectorY = input;
    }
};

/************************************************
Player class

    Player()            Constructs a Player object with no shields,
                        3000 energy, and 15 torpedoes.
    fireTorpedo()       Fires a torpedo at a player designated location
                        in the player's quadrant.
    depleteShields()    Sets the player's shields to 0.
    getCondition()      Returns a color coded condition based on the player's
                        energy level.
    getEnergy()         Returns the amount of energy the player has remaining.
    getShields()        Returns the amount of energy dedicated to shields.
    getTorpedoes()      Returns the amount of torpedoes the player has.
    setTorpedoes()      Sets the amount of torpedoes the player has.
    setShields()        Sets the player's shields to a specified amount.
    setEnergy()         Sets the player's energy to a specified amount.
    takeDamage()        Player takes a random amount of damage from 50 - 100 and potentially takes damage to a system.
    damageReport()      Displays a report of the Enterprise's system status.
    resupply()          Player's energy and torpedoes are replenished and all damage is repaired.
    setShields()        Allows a player to set the amount of energy dedicated to shields.
    getNavDisabled()    Returns status of navigation system.
    getSrsDisabled()    Returns status of short range scanning system.
    getLrsDisabled()    Returns status of long range scanning system.
    getSheDisabled()    Returns status of shield control system.
    getDamDisabled()    Returns status of damage report system.
    getComDisabled()    Returns status of library computer system.
    getPhaDisabled()    Returns status of phasers
    getTorDisabled()    Returns status of photon torpedos.
*************************************************/
class Player : public Object
{
private:
    int shields;
    int torpedoes;
    int energy;
    bool navDisabled;
    bool srsDisabled;
    bool lrsDisabled;
    bool phaDisabled;
    bool torDisabled;
    bool comDisabled;
    bool damDisabled;
    bool sheDisabled;

public:
    // Create a player with default attributes.
    Player()
    {
        shields = 0;
        energy = 3000;
        torpedoes = 15;
        navDisabled = 0;
        srsDisabled = 0;
        lrsDisabled = 0;
        phaDisabled = 0;
        torDisabled = 0;
        comDisabled = 0;
        damDisabled = 0;
        sheDisabled = 0;
    }

    // Fire a torpedo at a designated location in the player's quadrant.
    void fireTorpedo(Galaxy& galaxy)
    {
        int invalidMove = true;
        int shootDirection = 0;
        int shootDistance = 0;

        int qx = quadrantX;
        int qy = quadrantY;
        int sx = sectorX;
        int sy = sectorY;

        if (torpedoes < 1)
        {
            cout << "You are out of torpedoes!" << endl;
            return;
        }

        while (invalidMove == true)
        {
            cout << "4    3    2" << endl;
            cout << "  '  '  '  " << endl;
            cout << "   ' ' '   " << endl;
            cout << "5''''+''''1" << endl;
            cout << "   ' ' '   " << endl;
            cout << "  '  '  '  " << endl;
            cout << "6    7    8" << endl << endl;

            while (invalidMove == true)
            {
                cout << "Enter the direction you want to shoot: ";
                    cin >> shootDirection;

                if (shootDirection < 1 || shootDirection >= 9)
                {
                    cout<<"Invalid direction, try again!"<<endl;
                    invalidMove = true;
                }
                else
                    invalidMove = false;
            }

            cout << "Enter the distance you want to shoot: ";
                cin >> shootDistance;

            switch (shootDirection)
            {
                case 1:
                    sy = sectorY + shootDistance;
                    break;
                case 2:
                    sx = sectorX - shootDistance;
                    sy = sectorY + shootDistance;
                    break;
                case 3:
                    sx = sectorX - shootDistance;
                    break;
                case 4:
                    sx = sectorX - shootDistance;
                    sy = sectorY - shootDistance;
                    break;
                case 5:
                    sy = sectorY - shootDistance;
                    break;
                case 6:
                    sx = sectorX + shootDistance;
                    sy = sectorY - shootDistance;
                    break;
                case 7:
                    sx = sectorX + shootDistance;
                    break;
                case 8:
                    sx = sectorX + shootDistance;
                    sy = sectorY + shootDistance;
                    break;
            }

            if (galaxy.quadrantArray[qx][qy].sectorArray[sx][sy].hasEnemy() == 1)
                    {
                        cout << "Direct hit! Klingon warship destroyed!" << endl;
                        // Method to set enemy's status to dead.
                        galaxy.setKlingons(galaxy.getKlingons()-1);
                        galaxy.quadrantArray[qx][qy].sectorArray[sx][sy].setEnemy(0);
                    }
                    else
                        cout << "You didn't hit anything!" << endl;

                    torpedoes--;
            }
    }

    // Returns a condition string based on the player's total energy + shields.
    string getCondition()
    {
        string condition = "GREEN";

        if (energy + shields < 2000)
            condition = "YELLOW";

        if (energy + shields < 1000)
            condition = "RED";

        return condition;
    }

    // Returns the amount of energy the player has.
    int getEnergy()
    {
        return energy;
    }

    // Player takes a random amount of damage from 50 - 100 and potentially takes damage to a system.
    void takeDamage()
    {
        int randomDamage = rand() % 50 + 51;
        int randomSystem = rand() % 32 + 1;

        cout << "An Klingon warship fires upon you, dealing " << randomDamage << " damage to the Enterprise!" << endl;

        if (shields > 0)
        {
            shields = shields - randomDamage;
            if (shields < 0)
                shields = 0;
        }
        else
        {
            energy = energy - randomDamage;
            switch (randomSystem)
            {
                case 1:
                    if (navDisabled == 0)
                    {
                        cout << "Warp engines have taken critical damage!" << endl;
                        cout << "Navigation is now disabled!" << endl;
                        navDisabled = 1;
                    }
                    break;
                case 2:
                    if (srsDisabled == 0)
                    {
                        cout << "Short range sensors have taken critical damage!" << endl;
                        cout << "Short range scanning is now disabled!" << endl;
                        srsDisabled = 1;
                    }
                    break;
                case 3:
                    if (lrsDisabled == 0)
                    {
                        cout << "Long range sensors have taken critical damage!" << endl;
                        cout << "Long range scanning is now disabled!" << endl;
                        lrsDisabled = 1;
                    }
                    break;
                case 4:
                    if (phaDisabled == 0)
                    {
                        cout << "Phaser control has taken critical damage!" << endl;
                        cout << "Phasers are now disabled!" << endl;
                        phaDisabled = 1;
                    }
                    break;
                case 5:
                    if (torDisabled == 0)
                    {
                        cout << "Photon tubes have taken critical damage!" << endl;
                        cout << "Photon torpedoes are now disabled!" << endl;
                        torDisabled = 1;
                    }
                    break;
                case 6:
                    if (damDisabled == 0)
                    {
                        cout << "Damage control has taken critical damage!" << endl;
                        cout << "Damage reports are now disabled!" << endl;
                        damDisabled = 1;
                    }
                    break;
                case 7:
                    if (sheDisabled == 0)
                    {
                        cout << "Shield control has taken critical damage!" << endl;
                        cout << "Shield controls are now disabled!" << endl;
                        sheDisabled = 1;
                    }
                    break;
                case 8:
                    if (comDisabled == 0)
                    {
                        cout << "Library computer has taken critical damage!" << endl;
                        cout << "Library computer functions are now disabled!" << endl;
                        comDisabled = 1;
                    }
                    break;
                default:
                    break;
            }

        }
    }

    // Displays a report of the Enterprise's component status.
    void damageReport()
    {
        cout << " Device                  Status" << endl;
        cout << " ------                  ------" << endl;
        cout << " Warp Engines           ";
            if (navDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Short Range Sensors    ";
            if (srsDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Long Range Sensors     ";
            if (lrsDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Phasers                ";
            if (phaDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Photon Torpedos        ";
            if (torDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Damage control         ";
            if (damDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Shield Control         ";
            if (sheDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << " Library Computer       ";
            if (comDisabled == 0)
                cout << "Enabled" << endl;
            else
                cout << "Disabled" << endl;
        cout << endl;
    }

    // Player's energy and torpedoes are replenished and all damage is repaired.
    void resupply()
    {
        energy = 3000;
        torpedoes = 15;
        navDisabled = 0;
        srsDisabled = 0;
        lrsDisabled = 0;
        phaDisabled = 0;
        torDisabled = 0;
        comDisabled = 0;
        damDisabled = 0;
        sheDisabled = 0;
    }

    // Allows a player to set the amount of energy dedicated to shields.
    void setShields()
    {
        int sentinel = 0;
        int shieldPower;

        while (sentinel == 0)
        {
            cout << "Enter the amount of energy to allocate to shields: ";
                cin >> shieldPower;

            if (shieldPower < 0 || shieldPower > energy)
            {
                cout<<"Invalid amount, try again: "<<endl;
                sentinel = 0;
            }
            else
            {
                cout << "Allocating " << shieldPower << " to shields..." << endl;
                shields = shields + shieldPower;
                energy = energy - shieldPower;
                sentinel = 1;
            }
        }
    }

    int getShields()
    {
        return shields;
    }

    int getTorpedoes()
    {
        return torpedoes;
    }

    void setTorpedoes(int input)
    {
        torpedoes = input;
    }

    void depleteShields()
    {
        shields = 0;
    }

    void setEnergy(int input)
    {
        energy = input;
    }

    bool getNavDisabled()
    {
        return navDisabled;
    }

    bool getSrsDisabled()
    {
        return srsDisabled;
    }

    bool getLrsDisabled()
    {
        return lrsDisabled;
    }

    bool getSheDisabled()
    {
        return sheDisabled;
    }

    bool getDamDisabled()
    {
        return damDisabled;
    }

    bool getComDisabled()
    {
        return comDisabled;
    }

    bool getPhaDisabled()
    {
        return phaDisabled;
    }

    bool getTorDisabled()
    {
        return torDisabled;
    }
};

/************************************************
Enemy class

    Enemy()             Creates an enemy with 1000 energy (health)
    setEnergy()         Sets the enemy's energy to a specified amount.
    getEnergy()         Returns the enemy's energy.
*************************************************/
class Enemy: public Object
{
private:
    int energy;
public:
    Enemy()
    {
        energy = 500;
    }

    void setEnergy(int input)
    {
        energy = input;
    }

    int getEnergy()
    {
        return energy;
    }
};

/*****************
* Starbase class *
*****************/
class Starbase: public Object
{
};

/*************
* Star class *
*************/

class Star: public Object
{
};

#endif
