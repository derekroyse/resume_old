/************************************************
map.h - Map related classes header file.
      - Sector
      - Quadrant
      - Galaxy

Author: Derek Royse & Andy Pritt

Purpose: These classes store and print locational data.
*************************************************/
#ifndef MAP_H
#define MAP_H
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

// Galaxy/Quadrant dimensions.
const int XSIZE = 8;
const int YSIZE = 8;

/************************************************
Sector class

Member functions:
    Sector()        Initializes a sector with all attributes set to 0.
    hasPlayer()     Returns a 1 if the Sector contains a player or a 0 if not.
    hasEnemy()      Returns a 1 if the Sector contains an enemy or a 0 if not.
    hasStar()       Returns a 1 if the Sector contains a star or a 0 if not.
    hasBase()       Returns a 1 if the Sector contains a starbase or a 0 if not.
    setPlayer()     Modifies the isPlayer attribute.
    setEnemy()      Modifies the isEnemy attribute.
    setStar()       Modifies the isStar attribute.
    setBase()       Modifies the isBase attribute.
*************************************************/
class Sector
{
    private:
        bool isPlayer;
        bool isEnemy;
        bool isStar;
        bool isBase;
    public:
        Sector()
        {
            isPlayer = 0;
            isEnemy = 0;
            isStar = 0;
            isBase = 0;
        }

        bool hasPlayer()
        {
            return isPlayer;
        }

        bool hasEnemy()
        {
            return isEnemy;
        }

        bool hasStar()
        {
            return isStar;
        }

        bool hasBase()
        {
            return isBase;
        }

        void setPlayer(int input)
        {
            isPlayer = input;
        }

        void setEnemy(int input)
        {
            isEnemy = input;
        }

        void setStar(int input)
        {
            isStar = input;
        }

        void setBase(int input)
        {
            isBase = input;
        }
};

/************************************************
Quadrant class

Member functions:
    initializeQuadrant()    Initialize a quadrant with all attributes set to 0
    printQuadrant()         Display the quadrant on screen.
    getEnemy()              Returns a 1 if the Quadrant contains an enemy, 0 otherwise.
    getRevealed()           Returns a 1 if the Quadrant has been revealed by
                            a short range scan. 0 otherwise.
    setRevealed()           Modify the 'revealed' attribute
    getNumEnemies()         Returns the number of Klingons in the quadrant.
    getNumStars()           Returns the number of Stars in the quadrant.
    getNumBases()           Returns the number of Starbases in the quadrant.
*************************************************/
class Quadrant
{
    private:
        // 1 = revealed by short range scan.
        bool revealed;

    public:
        // An array of Sector objects.
        Sector sectorArray[XSIZE][YSIZE];

        // Loop through the quadrant, initializing all attributes to 0.
        void initializeQuadrant()
        {
            for (int i = 0; i < XSIZE; i++)
                for (int j = 0; j < YSIZE; j++)
                {
                    sectorArray[i][j].setPlayer(0);
                    sectorArray[i][j].setEnemy(0);
                    sectorArray[i][j].setStar(0);
                    sectorArray[i][j].setBase(0);
                    revealed = 0;
                }
        }

        // Loop through the quadrant, displaying an appropriate symbol
        // for the content of each Sector.
        void printQuadrant()
        {
            for (int i = 0; i < XSIZE; i++)
            {
                cout << '|';
                for (int j = 0; j < YSIZE; j++)
                {
                    if (sectorArray[i][j].hasPlayer() == 1)
                        cout << 'P';
                    else if (sectorArray[i][j].hasBase() == 1)
                        cout << 'B';
                    else if (sectorArray[i][j].hasEnemy() == 1 && revealed == 1)
                        cout << 'E';
                    else if (sectorArray[i][j].hasEnemy() == 1 && revealed == 0)
                        cout << '-';
                    else if (sectorArray[i][j].hasStar() == 1)
                        cout << '*';
                    else if (sectorArray[i][j].hasPlayer() == 1)
                        cout << 'P';
                    else
                        cout << '-';
                }
                cout << '|';
            }
        }

        // Return whether an enemy exists anywhere in the Quadrant.
        bool getEnemy()
        {
            for (int i = 0; i < XSIZE; i++)
            {
                for (int j = 0; j < YSIZE; j++)
                {
                    if (sectorArray[i][j].hasEnemy() == 1)
                        return 1;
                }
            }
            return 0;
        }

        // Return state of 'revealed' attribute.
        bool getRevealed()
        {
            return revealed;
        }

        // Change state of 'revealed' attribute.
        void setRevealed(bool input)
        {
            revealed = input;
        }

        // Return the number of enemies in the quadrant.
        char getNumEnemies()
        {
            int counter = 0;
            for (int i = 0; i < XSIZE; i++)
                for (int j = 0; j < YSIZE; j++)
                    if (sectorArray[i][j].hasEnemy() == 1)
                        counter++;

            if (counter < 0 || counter > 9)
                return '*';
            else
                return '0' + counter;
        }

        // Return the number of stars in the quadrant.
        char getNumStars()
        {
            int counter = 0;
            for (int i = 0; i < XSIZE; i++)
                for (int j = 0; j < YSIZE; j++)
                    if (sectorArray[i][j].hasStar() == 1)
                        counter++;

            if (counter < 0 || counter > 9)
                return '*';
            else
                return '0' + counter;
        }

        // Return number of Starbases in a quadrant.
        char getNumBases()
        {
            int counter = 0;
            for (int i = 0; i < XSIZE; i++)
                for (int j = 0; j < YSIZE; j++)
                    if (sectorArray[i][j].hasBase() == 1)
                        counter++;

            if (counter < 0 || counter > 9)
                return '*';
            else
                return '0' + counter;
        }
};

/************************************************
Galaxy class

Member functions:
 Galaxy()
    Galaxy()                Create a Galaxy object.
    printGalaxy()           Display the entire Galaxy on screen.
                            Used for testing.
    populateGalaxy()        Randomly spawns player, enemies, stars,
                            and starbases in unique locations.
    getStarbases()          Returns the number of Starbases in the galaxy.
    getKlingons()           Returns number of Klingons left in the galaxy.
    setKlingons()           Modifies the number of Klingons in the galaxy.
*************************************************/
class Galaxy
{
    private:
        int numKlingons;
        int numStarbases;
    public:
        // An array of Quadrants.
        Quadrant quadrantArray[XSIZE][YSIZE];

        // Create a Galaxy.
        Galaxy()
        {
            for (int i = 0; i < XSIZE; i++)
            {
                for (int j = 0; j < YSIZE; j++)
                {
                    quadrantArray[i][j].initializeQuadrant();
                }
            }
        }

        // Display the entire Galaxy.
        void printGalaxy()
        {
            for (int x = 0; x < XSIZE; x++)
            {
                for (int y = 0; y < YSIZE; y++)
                {
                    for (int i = 0; i < XSIZE; i++)
                    {
                        cout << '|';
                        for (int j = 0; j < YSIZE; j++)
                        {
                            if (quadrantArray[x][i].sectorArray[y][j].hasBase() == 1)
                                cout << 'B';
                            else if (quadrantArray[x][i].sectorArray[y][j].hasEnemy() == 1)
                                cout << 'E';
                            else if (quadrantArray[x][i].sectorArray[y][j].hasStar() == 1)
                                cout << '*';
                            else if (quadrantArray[x][i].sectorArray[y][j].hasPlayer() == 1)
                                cout << 'P';
                            else
                                cout << '-';
                        }
                        cout << '|';
                    }
                }
                cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
            }
        }

        // Spawn all entities in the Galaxy.
        void populateGalaxy()
        {
            int x;
            int y;
            int i;
            int j;
            int random;
            int counter = 0;

            // x, y, i, and j range between 0 and 7.
            x = rand() % XSIZE;
            y = rand() % YSIZE;
            i = rand() % XSIZE;
            j = rand() % YSIZE;

            // Spawn a random number of enemies (anywhere from 5 to 15)
            random = rand() % 11 + 5;
            while (counter < random)
            {
                numKlingons = random;
                if(quadrantArray[x][y].sectorArray[i][j].hasStar() == 0 && quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 0 &&
                   quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 0 && quadrantArray[x][y].sectorArray[i][j].hasBase() == 0)
                {
                        quadrantArray[x][y].sectorArray[i][j].setEnemy(1);
                        counter++;
                }

                else
                {
                    x = rand() % XSIZE;
                    y = rand() % YSIZE;
                    i = rand() % XSIZE;
                    j = rand() % YSIZE;
                }
            }

            // Spawn stars (anywhere from 5 to 30)
            random = rand() % 25 + 5;
            counter = 0;
            while (counter < random)
            {
                if(quadrantArray[x][y].sectorArray[i][j].hasStar() == 0 && quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 0 &&
                   quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 0 && quadrantArray[x][y].sectorArray[i][j].hasBase() == 0)
                {
                        quadrantArray[x][y].sectorArray[i][j].setStar(1);
                        counter++;
                }
                else
                {
                    x = rand() % XSIZE;
                    y = rand() % YSIZE;
                    i = rand() % XSIZE;
                    j = rand() % YSIZE;
                }
            }

            // Spawn bases (anywhere from 1 to 5)
            counter = 0;
            random = rand() % 5 + 1;
            numStarbases = random;
            while (counter < random)
            {
                if(quadrantArray[x][y].sectorArray[i][j].hasStar() == 0 && quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 0 &&
                   quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 0 && quadrantArray[x][y].sectorArray[i][j].hasBase() == 0)
                {
                        quadrantArray[x][y].sectorArray[i][j].setBase(1);
                        counter++;
                }
                else
                {
                    x = rand() % XSIZE;
                    y = rand() % YSIZE;
                    i = rand() % XSIZE;
                    j = rand() % YSIZE;
                }
            }

            // Spawn player (only one)
            counter = 0;
            while (counter < 1)
            {
                if(quadrantArray[x][y].sectorArray[i][j].hasStar() == 0 && quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 0 &&
                   quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 0 && quadrantArray[x][y].sectorArray[i][j].hasBase() == 0)
                {
                        quadrantArray[x][y].sectorArray[i][j].setPlayer(1);
                        counter++;
                }
                else
                {
                    x = rand() % XSIZE;
                    y = rand() % YSIZE;
                    i = rand() % XSIZE;
                    j = rand() % YSIZE;
                }
            }
        }

        // Returns the numStarbases attribute.
        int getStarbases()
        {
            return numStarbases;
        }

        // Returns the numKlingons attribute.
        int getKlingons()
        {
            return numKlingons;
        }

        // Modify the numKlingons attribute.
        void setKlingons(int input)
        {
            numKlingons = input;
        }
};

#endif
