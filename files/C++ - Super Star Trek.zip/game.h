/*******************************************
game.h - Game class header file.

Author: Derek Royse and Andy Pritt

Purpose: Definition of Game object which handles
internal game functions and relations between classes.
*******************************************/

#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "map.h"
#include "object.h"
#include "computer.h"

using namespace std;

/************************************************
Game class

Member functions:
    Game()                  Starts a game with a random Stardate.
    run()                   Start and end a new game of Super Star Trek.
    determineInput()        Translates player input to game functions.
    chooseMove()            Chooses whether to move a player by sector or by quadrant.
    sectorMove()            Move a player from sector to sector.
    quadrantMove()          Move a player to the same sector in a different quadrant.
    updatePlayerLocation()  Update the Player objects internal location data.
    populateEnemyList()     Assign the Game's Enemy array objects coordinates that match the
                            locations of enemies in the Galaxy.
    boundaryMessage()       Display a message alerting the player they have
                            encountered a galactic boundary.
    firePhaser()            Fires a phaser with player designated strength at an enemy.
    printHelp()             Prints a list of available commands.
    getCurrentStardate()    Returns current Stardate.
    getInitialStardate()    Returns the Stardate in which the game began.
    printTitle()            Prints the title screen.
    refresh()               Clears the current screen and displays the status screen.
*************************************************/
class Game
{
private:
    int initStardate;
    int currentStardate;
    Enemy enemyArray[16];
public:
    // Start a game with a random Stardate between 2000 and 3900.
    Game()
    {
        initStardate = (rand() % 20 + 20) * 100;
        currentStardate = initStardate;
    }

    // Start and end a game of Super Star Trek.
    void run()
    {
        // Variables
        string mainInput;
        int result = 0;
        bool sentinel = 0;

        // Create classes.
        Player player1;
        Galaxy galaxy1;
        Computer com1;

        // Initialization
        galaxy1.populateGalaxy();
        updatePlayerLocation(player1, galaxy1);
        populateEnemyList(galaxy1);

        // Display the title screen.
        printTitle(galaxy1);
        system("pause");
        system("cls");

        com1.printStatusScreen(player1, galaxy1, initStardate, currentStardate);

        // Until the player is killed, all Klingons are destroyed, or the time limit is reached
        // ask for input. End the game when one of the above conditions are met.
        while (sentinel == 0)
        {
            // Get and perform player input.
            cout << "Command: ";
               cin >> mainInput;
            determineInput(mainInput, player1, galaxy1, com1);

            // End-game tests.
            if (galaxy1.getKlingons() == 0)
            {
                    system("cls");
                    sentinel = 1;
                    cout << "CONGRATULATIONS! You destroyed all the Klingons in time to save Earth!" << endl;
            }
            else if (player1.getEnergy() + player1.getShields() <= 0)
            {
                    system("cls");
                    sentinel = 1;
                    cout << "GAME OVER! Your ship was destroyed and your crew was lost..." << endl;
            }

            else if (currentStardate > initStardate + 50)
            {
                    system("cls");
                    sentinel = 1;
                    cout << "GAME OVER! You ran out of time!" << endl;
            }
        }
    }

    // Translate multiple player commands to game actions.
    void determineInput(string input, Player& player, Galaxy& galaxy, Computer computer)
    {
        int comInput;
        int sentinel = 0;

        // nav
        if (input == "n" || input == "N" ||input == "nav" ||input == "NAV" ||
            input == "navigate" || input == "NAVIGATE" ||input == "navigation" ||input == "NAVIGATION" ||
            input == "move" || input == "MOVE")
            {
                if (player.getNavDisabled() == 1)
                {
                    cout << "Navigation is disabled!" << endl;
                    return;
                }
                else
                {
                    system("cls");
                    computer.printStatusScreen(player, galaxy, initStardate, currentStardate);
                    chooseMove(player, galaxy);
                }

            refresh(player, galaxy, computer);
            }

        // help
        else if (input == "h" || input == "H" ||input == "help" ||input == "HELP")
        {
            system("cls");
            computer.printStatusScreen(player, galaxy, initStardate, currentStardate);
            printHelp();
        }

        // srs
        else if (input == "srs" || input == "SRS" ||input == "sr" ||input == "SR" ||
                 input == "short range scanner" ||input == "SHORT RANGE SCANNER")
        {
            if (player.getSrsDisabled() == 1)
            {
                cout << "Short range scanning is disabled!" << endl;
                return;
            }
            else
                computer.shortRangeScanner(player, galaxy, initStardate, currentStardate);

            refresh(player, galaxy, computer);
        }

        // lrs
        else if (input == "lrs" || input == "LRS" ||input == "l" ||input == "L" ||
                 input == "long range scanner" ||input == "LONG RANGE SCANNER")
        {
            if (player.getLrsDisabled() == 1)
            {
                cout << "Long range scanning is disabled!" << endl;
                return;
            }
            else
                computer.printLongRangeScanner(player, galaxy);

            refresh(player, galaxy, computer);
        }

        // pha
        else if (input == "pha" || input == "PHA" ||input == "p" ||input == "P" ||
                 input == "phasers" ||input == "PHASERS")
        {
            if (player.getPhaDisabled() == 1)
            {
                cout << "Phasers are disabled!" << endl;
                return;
            }
            else
            {
                firePhaser(player, galaxy);
            }

            refresh(player, galaxy, computer);
        }

        // tor
        else if (input == "tor" || input == "TOR" ||input == "t" ||input == "T" ||
                 input == "torpedos" ||input == "TORPEDOS")
        {
            if (player.getTorDisabled() == 1)
            {
                cout << "Torpedos are disabled!" << endl;
                return;
            }
            else
            {
                player.fireTorpedo(galaxy);
            }

            refresh(player, galaxy, computer);
        }

        // she
        else if (input == "she" || input == "SHE" ||input == "sh" ||input == "SH" ||
                 input == "sheild" ||input == "SHIELD")
        {
            if (player.getSheDisabled() == 1)
            {
                cout << "Shield controls are disabled!" << endl;
                return;
            }
            else
                player.setShields();

            refresh(player, galaxy, computer);
        }

        // dam
        else if (input == "dam" || input == "DAM" ||input == "d" ||input == "D" ||
                 input == "damage" ||input == "DAMAGE")
        {
            if (player.getDamDisabled() == 1)
            {
                cout << "Damage control is disabled!" << endl;
                return;
            }
            else
                player.damageReport();

            refresh(player, galaxy, computer);
        }

        // com
        else if (input == "com" || input == "COM" ||input == "c" ||input == "C" ||
                 input == "computer" ||input == "COMPUTER")
        {
            if (player.getComDisabled() == 1)
            {
                cout << "Library computer is disabled!" << endl;
                return;
            }
            else
            {
                while (sentinel == 0)
                {
                    cout << "Computer active and awaiting command.";
                        cin >> comInput;
                    switch (comInput)
                    {
                        case 0:
                            cout << "Generating Galactic Record: " << endl;
                            system("cls");
                            computer.printGalacticRecord(player, galaxy);
                            sentinel = 1;
                            break;
                        case 1:
                            cout << "Generating Status Report: " << endl;
                            computer.printStatusReport(galaxy, initStardate, currentStardate);
                            sentinel = 1;
                            break;
                        case 2:
                            cout << "Activating Torpedo Targeting Computer: " << endl;
                            computer.getTargetingData(player, galaxy);
                            sentinel = 1;
                            break;
                        case 3:
                            cout << "Activating Federation Starbase Navigation Charts: " << endl;
                            computer.getStarbaseData(player, galaxy);
                            sentinel = 1;
                            break;
                        case 4:
                            cout << "Activating Navigational Computer..." << endl;
                            computer.printNavData(player);
                            sentinel = 1;
                            break;
                        case 5:
                            system("cls");
                            cout << "Displaying galaxy map: " << endl;
                            computer.printGalaxyMap();
                            sentinel = 1;
                            break;
                        default:
                            cout << "Invalid command!" << endl;
                            cout << "0: Galactic Record" << endl;
                            cout << "1: Status Report" << endl;
                            cout << "2: Photon Torpedo Data" << endl;
                            cout << "3: Starbase Nav Data" << endl;
                            cout << "4: Directional/Distance Data" << endl;
                            cout << "5: Galactic Region Name Map" << endl;
                            break;
                    }
                }
            }
            refresh(player, galaxy, computer);
        }

        // xxx
        else if (input == "xxx" || input == "XXX")
        {
            cout << "You resign your command..." << endl;
            currentStardate = currentStardate + 51;
        }

        else
        {
            printHelp();
        }
    }

    // Get direction and distance information from the player.
    // Determine whether or not the player is crossing into a new
    // quadrant or not, and then move them accordingly.
    // Also contains error checking to prevent players from leaving the galaxy.
    void chooseMove(Player& player, Galaxy& galaxy)
    {
        int direction;
        float distance;
        int counter = 0;

            cout << "4    3    2" << endl;
            cout << "  '  '  '  " << endl;
            cout << "   ' ' '   " << endl;
            cout << "5''''+''''1" << endl;
            cout << "   ' ' '   " << endl;
            cout << "  '  '  '  " << endl;
            cout << "6    7    8" << endl << endl;

            cout << "Navigational Course (0 - 8): ";
                cin >> direction;
            cout << "Warp Factor (0 - 8): ";
                cin >> distance;

                // If the distance is a float, convert it to an int.
                // Also increments the Stardate by the proper amount
                // depending on the player's action.
                int distanceInt = 0;
                if (fmod (distance,1) != 0.0)
                {
                    distanceInt = distance * 10;
                    currentStardate += 1;
                }
                else
                {
                    currentStardate += 2;
                    distanceInt = distance * XSIZE;
                }

                // Error Checking
                if (distanceInt < 1 || distanceInt > XSIZE * YSIZE)
                {
                    cout << "Invalid warp speed. Returning to main command." << endl;
                    return;
                }
                if (direction < 0 || direction > 8)
                {
                    cout << "Invalid direction. Returning to main command." << endl;
                    return;
                }

                // Check to ensure the player's movement will not take them beyond a galactic border.
                // If not, then check if the player's movement will take them into a new quadrant,
                // and if so, move them into the proper position in the new quadrant. If the player's
                // movement will not take them into a new quadrant, simply move them into the proper sector.
                while (counter < distanceInt)
                {
                    switch (direction)
                    {
                        // Right
                        case 1:
                            if (player.getQuadrantY() == YSIZE-1 && player.getSectorY() == YSIZE-1)
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorY() == YSIZE-1)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Up-Right
                        case 2:
                            if ((player.getQuadrantX() == 0 && player.getSectorX() == 0) ||
                                (player.getQuadrantY() == YSIZE-1 && player.getSectorY() == YSIZE-1))
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == 0 || player.getSectorY() == YSIZE-1)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Up
                        case 3:
                            if (player.getQuadrantX() == 0 && player.getSectorX() == 0)
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == 0)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Up-Left
                        case 4:
                            if ((player.getQuadrantX() == 0 && player.getSectorX() == 0) ||
                                (player.getQuadrantY() == 0 && player.getSectorY() == 0))
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == 0|| player.getSectorY() == 0)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Left
                        case 5:
                            if (player.getQuadrantY() == 0 && player.getSectorY() == 0)
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorY() == 0)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Down-Left
                        case 6:
                            if ((player.getQuadrantX() == XSIZE-1 && player.getSectorX() == XSIZE-1) ||
                                (player.getQuadrantY() == 0 && player.getSectorY() == 0))
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == XSIZE-1 || player.getSectorY() == 0)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Down
                        case 7:
                            if (player.getQuadrantX() == XSIZE-1 && player.getSectorX() == XSIZE-1)
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == XSIZE-1)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;

                        // Down Right
                        case 8:
                            if ((player.getQuadrantX() == XSIZE-1 && player.getSectorX() == XSIZE-1) ||
                                (player.getQuadrantY() == YSIZE-1 && player.getSectorY() == YSIZE-1))
                            {
                                boundaryMessage();
                                return;
                            }
                            else if (player.getSectorX() == XSIZE-1 || player.getSectorY() == YSIZE-1)
                            {
                                quadrantMove(direction, player, galaxy);
                                counter++;
                            }
                            else
                            {
                                sectorMove(direction, player, galaxy);
                                counter++;
                            }
                            break;
                    }
                }

        // Fuel cost.
        if (distanceInt >= 8)
            player.setEnergy(player.getEnergy() - 10 * (distanceInt/8));
        else
            player.setEnergy(player.getEnergy() - 5 * distanceInt);


        // If any enemies are in the quadrant, they fire upon the player.
        if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].getEnemy() == 1 && fmod (distance,1) != 0.0)
            player.takeDamage();
    }

    // Move a player between sectors.
    void sectorMove(int direction, Player& player, Galaxy& galaxy)
    {
        int x = player.getQuadrantX();
        int y = player.getQuadrantY();
        int i = player.getSectorX();
        int j = player.getSectorY();

        switch (direction)
        {
            // Right
            case 1:
                player.setSectorY(j+1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i][j+1].setPlayer(1);
                break;
            // Up-Right
            case 2:
                player.setSectorX(i-1);
                player.setSectorY(j+1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i-1][j+1].setPlayer(1);
                break;
            // Up
            case 3:
                player.setSectorX(i-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i-1][j].setPlayer(1);
                break;
            // Up-Left
            case 4:
                player.setSectorX(i-1);
                player.setSectorY(j-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i-1][j-1].setPlayer(1);
                break;
            // Left
            case 5:
                player.setSectorY(j-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i][j-1].setPlayer(1);
                break;
            // Down-Left
            case 6:
                player.setSectorX(i+1);
                player.setSectorY(j-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i+1][j-1].setPlayer(1);
                break;
            // Down
            case 7:
                player.setSectorX(i+1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i+1][j].setPlayer(1);
                break;
            // Down-Right
            case 8:
                player.setSectorX(i+1);
                player.setSectorY(j+1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y].sectorArray[i+1][j+1].setPlayer(1);
                break;
        }

        // Conditional statements to check if a player shares the same space with another object.
        if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasBase() == 1)
        {
            cout << "You have successfully docked with a Federation starbase." << endl;
            cout << "Your energy and torpedoes are fully restored!" << endl;
            player.resupply();
        }
        if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasEnemy() == 1)
        {
            cout << "You collided with a Klingon warship and died!" << endl;
            player.setEnergy(0);
            player.depleteShields();
        }
        if  (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasStar() == 1)
        {
            cout << "You collided with a star and died!" << endl;
            player.setEnergy(0);
            player.depleteShields();
        }
    }

    // Move a player between quadrants.
    void quadrantMove(int direction, Player& player, Galaxy& galaxy)
    {
        int x = player.getQuadrantX();
        int y = player.getQuadrantY();
        int i = player.getSectorX();
        int j = player.getSectorY();

        switch (direction)
        {
            // Right
            case 1:
                player.setQuadrantY(y+1);
                player.setSectorY(0);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y+1].sectorArray[i][0].setPlayer(1);
                break;
            // Up-Right
            case 2:
                if (i == 0 && j == YSIZE-1)
                {
                    player.setQuadrantX(x-1);
                    player.setQuadrantY(y+1);
                    player.setSectorX(XSIZE-1);
                    player.setSectorY(0);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x-1][y+1].sectorArray[XSIZE-1][0].setPlayer(1);
                }
                else if (j == YSIZE-1)
                {
                    player.setQuadrantY(y+1);
                    player.setSectorX(i-1);
                    player.setSectorY(0);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x][y+1].sectorArray[i-1][0].setPlayer(1);
                }
                else if (i == 0)
                {
                    player.setQuadrantX(x-1);
                    player.setSectorX(XSIZE-1);
                    player.setSectorY(j+1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x-1][y].sectorArray[XSIZE-1][j+1].setPlayer(1);
                }
                break;
            // Up
            case 3:
                player.setQuadrantX(x-1);
                player.setSectorX(XSIZE-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x-1][y].sectorArray[XSIZE-1][j].setPlayer(1);
                break;
            // Up-Left
            case 4:
                if (i == 0 && j == 0)
                {
                    player.setQuadrantX(x-1);
                    player.setQuadrantY(y-1);
                    player.setSectorX(XSIZE-1);
                    player.setSectorY(YSIZE-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x-1][y-1].sectorArray[XSIZE-1][YSIZE-1].setPlayer(1);
                }
                else if (i == 0)
                {
                    player.setQuadrantX(x-1);
                    player.setSectorX(XSIZE-1);
                    player.setSectorY(j-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x-1][y+1].sectorArray[XSIZE-1][j-1].setPlayer(1);
                }
                else if (j == 0)
                {
                    player.setQuadrantY(y-1);
                    player.setSectorX(i-1);
                    player.setSectorY(XSIZE-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x][y-1].sectorArray[i-1][XSIZE-1].setPlayer(1);
                }
                break;
            // Left
            case 5:
                player.setQuadrantY(y-1);
                player.setSectorY(YSIZE-1);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x][y-1].sectorArray[i][YSIZE-1].setPlayer(1);
                break;
            // Down-Left
            case 6:
                if (i == XSIZE-1 && j == 0)
                {
                    player.setQuadrantX(x+1);
                    player.setQuadrantY(y-1);
                    player.setSectorX(0);
                    player.setSectorY(YSIZE-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x+1][y-1].sectorArray[0][YSIZE-1].setPlayer(1);
                }
                else if (i == XSIZE-1)
                {
                    player.setQuadrantX(x+1);
                    player.setSectorX(0);
                    player.setSectorY(j-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x+1][y].sectorArray[0][j-1].setPlayer(1);
                }
                else if (j == 0)
                {
                    player.setQuadrantY(y-1);
                    player.setSectorX(i+1);
                    player.setSectorY(YSIZE-1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x][y-1].sectorArray[i+1][YSIZE-1].setPlayer(1);
                }
                break;
            // Down
            case 7:
                player.setQuadrantX(x+1);
                player.setSectorX(0);
                galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                galaxy.quadrantArray[x+1][y].sectorArray[0][j].setPlayer(1);
                break;
            // Down-Right
            case 8:
                if (i == XSIZE-1 && j == YSIZE)
                {
                    player.setQuadrantX(x+1);
                    player.setQuadrantY(y+1);
                    player.setSectorX(0);
                    player.setSectorY(0);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x+1][y+1].sectorArray[0][0].setPlayer(1);
                }
                else if (i == XSIZE-1)
                {
                    player.setQuadrantX(x+1);
                    player.setSectorX(0);
                    player.setSectorY(j+1);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x+1][y].sectorArray[0][j+1].setPlayer(1);
                }
                else if (j == YSIZE)
                {
                    player.setQuadrantY(y+1);
                    player.setSectorX(i+1);
                    player.setSectorY(0);
                    galaxy.quadrantArray[x][y].sectorArray[i][j].setPlayer(0);
                    galaxy.quadrantArray[x][y+1].sectorArray[i+1][0].setPlayer(1);
                }
                break;
        }

        // Conditional statements to check if a player shares the same space with another object.
        if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasBase() == 1)
        {
            cout << "You have successfully docked with a Federation starbase." << endl;
            cout << "Your energy and torpedoes are fully restored!" << endl;
            player.resupply();
        }
        if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasEnemy() == 1)
        {
            cout << "You collided with a Klingon warship and died!" << endl;
            player.setEnergy(0);
            player.depleteShields();
        }
        if  (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[player.getSectorX()][player.getSectorY()].hasStar() == 1)
        {
            cout << "You collided with a star and died!" << endl;
            player.setEnergy(0);
            player.depleteShields();
        }
    }

    // Search through the galaxy to find the player, then update its coordinates.
    void updatePlayerLocation(Player& player, Galaxy galaxy)
    {
        for (int x = 0; x < XSIZE; x++)
            for (int y = 0; y < YSIZE; y++)
                for (int i = 0; i < XSIZE; i++)
                    for (int j = 0; j < YSIZE; j++)
                    {
                        if(galaxy.quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 1)
                        {
                            player.setQuadrantX(x);
                            player.setQuadrantY(y);
                            player.setSectorX(i);
                            player.setSectorY(j);
                        }
                    }
        }

    // Assign the Game's Enemy array objects coordinates that match the
    // locations of enemies in the Galaxy.
    void populateEnemyList(Galaxy& galaxy)
    {
        int counter = 1;

        for (int x = 0; x < XSIZE; x++)
            for (int y = 0; y < YSIZE; y++)
                for (int i = 0; i < XSIZE; i++)
                    for (int j = 0; j < YSIZE; j++)
                    {
                        if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 1)
                        {
                            enemyArray[counter].setQuadrantX(x);
                            enemyArray[counter].setQuadrantY(y);
                            enemyArray[counter].setSectorX(i);
                            enemyArray[counter].setSectorY(j);
                            counter++;
                        }
                    }
    }

    // Fires a phaser with a designated amount of energy at an enemy ship
    void firePhaser (Player& player, Galaxy& galaxy)
    {
        int energyInput;
        bool properInput = 0;
        bool firedSentinel = 0;

            for (int i = 0; i < XSIZE; i++)
                for (int j = 0; j < YSIZE; j++)
                    if (galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[i][j].hasEnemy() == 1)
                    {
                        while (properInput == 0)
                        {
                            cout << "Enemy starship detected! Please enter the energy to dedicate to phasers: ";
                                cin >> energyInput;
                            if (energyInput == 0)
                            {
                                cout << "Cancelling phaser shot..." << endl;
                                return;
                            }
                            else if (energyInput < player.getEnergy() && energyInput >= 1)
                            {
                                firedSentinel = 1;
                                properInput = 1;
                            }
                            else
                            {
                                cout << "Cannot dedicate that amount of energy to phasers." << endl;
                                cout << "Please try again..." << endl;
                            }
                        }

                        for (int q = 1; q < 16; q++)
                            if (enemyArray[q].getQuadrantX() == player.getQuadrantX() &&
                                enemyArray[q].getQuadrantY() == player.getQuadrantY() &&
                                enemyArray[q].getSectorX() == i && enemyArray[q].getSectorY() == j)
                            {
                                cout << "Firing on enemy ship. Klingon warship has " << enemyArray[q].getEnergy() << " energy remaining." << endl << endl;
                                enemyArray[q].setEnergy(enemyArray[q].getEnergy() - energyInput);
                                cout << "Enemy ship takes " << energyInput << " points of damage and has " << enemyArray[q].getEnergy() << " energy remaining." << endl << endl;
                                if (enemyArray[q].getEnergy() < 1)
                                {
                                    cout << "Enemy Klingon destroyed!" << endl << endl;
                                    galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].sectorArray[i][j].setEnemy(0);
                                    enemyArray[q].setQuadrantX(-1);
                                    enemyArray[q].setQuadrantY(-1);
                                    enemyArray[q].setSectorX(-1);
                                    enemyArray[q].setSectorY(-1);
                                    galaxy.setKlingons(galaxy.getKlingons()-1);
                                }
                                else
                                {
                                    player.takeDamage();
                                }
                            }
                    }

            if (firedSentinel == 0)
                cout << "No Klingons to fire upon." << endl;
    }

    // Print help screen with a list of commands.
    void printHelp()
    {
        cout << "Enter one of the following: " << endl
             << "nav - To Set Course"  << endl
             << "srs - Short Range Sensors" << endl
             << "lrs - Long Range Sensors"  << endl
             << "pha - Phasers"  << endl
             << "tor - Photon Torpedoes"  << endl
             << "she - Sheild Control"  << endl
             << "dam - Damage Control"  << endl
             << "com - Library Computer"  << endl
             << "xxx - Resign Command"  << endl;
    }

    // Display a lengthy message to the player when they attempt to leave the galaxy.
    void boundaryMessage()
    {
        cout << "LT. Uhura reports: " << endl << "  Message from Starfleet Command:" << endl << endl <<
        "Permission to attempt crossing of galactic perimeter" << endl << "is hereby *denied*. Shut down your engines."
        << endl << endl;
        return;
    }

    // Return current Stardate.
    int getCurrentStardate()
    {
        return currentStardate;
    }

    // Return initial Stardate.
    int getInitialStardate()
    {
        return initStardate;
    }

    // Print the title screen.
    void printTitle(Galaxy galaxy)
        {
        ifstream infile("title.txt");
        infile.unsetf(ios_base::skipws);
        char titleArray[32][80];
        for (int i = 0; i < 32; i++)
            for (int j = 0; j < 80; j++)
                infile >> titleArray[i][j];

        titleArray[24][12] = '0' + galaxy.getKlingons() / 10;
        titleArray[24][13] = '0' + galaxy.getKlingons() % 10;
        titleArray[26][-1] = '0' + (initStardate + 50) / 1000;
        titleArray[26][0]  = '0' + (initStardate + 50) / 100 % 10;
        titleArray[26][1]  = '0' + ((initStardate + 50) / 10) % 10;
        titleArray[26][2]  = '0' + (initStardate + 50) % 10;
        titleArray[27][42] = '0' + galaxy.getStarbases();

        for (int i = 0; i < 32; i++)
            for (int j = 0; j < 80; j++)
                if (titleArray[i][j] != '\n')
                    cout << titleArray[i][j];
        cout << "      ";
        }

    // Clears the screen and prints a new status screen.
    void refresh(Player player, Galaxy galaxy, Computer computer)
    {
            system("pause");
            system("cls");
            computer.printStatusScreen(player, galaxy, initStardate, currentStardate);
    }
};

#endif
