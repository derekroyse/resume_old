/************************************************
computer.h   Computer and Scan related functions.

Author: Derek Royse & Andy Pritt

Purpose: This class holds all the computer and scan functions.
*************************************************/
#ifndef COMPUTER_H
#define COMPUTER_H
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

/************************************************
Computer class

Member functions:
    printGalacticRecord()   Prints out a record of all player's scans.
    printLongRangeScanner() Prints out a scan of the player's adjacent quadrants.
    printStatusReport()     Displays the number of klingons, time, and starbases remaining.
    printGalaxyMap()        Prints a map of the 16 major galactic regions and their names.
    getTargetingData()      Prints targeting data to all Klingons in the player's quadrant.
    getStarbaseData()       Prints directions to all starbases in the player's quadrant.
    printNavData()          Display navigational data to any Sector in the Galaxy.
    shortRangeScanner()     Reveal all objects in the player's current Quadrant.
    printStatusScreen()     Prints out a screen displaying the player's current quadrant
                            all all available status data.
    translateRegion()       Determines the player's region based on it's coordinates.
*************************************************/
class Computer
{
public:

   // Print out a record of all scanned Quadrants.
    void printGalacticRecord(Player player, Galaxy galaxy)
    {
        int x = player.getQuadrantX();
        int y = player.getQuadrantY();

        cout << "     Computer Record of Galaxy for Quadrant" << x << ',' << y << endl << endl;
        cout << "     0     1     2     3     4     5     6     7  " << endl;
        cout << "   ----- ----- ----- ----- ----- ----- ----- -----" << endl;

        for (int i = 0; i < XSIZE; i++)
        {
            cout << i << "   ";
            for (int j = 0; j < YSIZE; j++)
            {
                if (galaxy.quadrantArray[i][j].getRevealed() == 1)
                {
                    cout << galaxy.quadrantArray[i][j].getNumEnemies();
                    cout << galaxy.quadrantArray[i][j].getNumBases();
                    cout << galaxy.quadrantArray[i][j].getNumStars();
                    cout << "   ";
                }
                else
                {
                    cout << '*';
                    cout << '*';
                    cout << '*';
                    cout << "   ";
                }
            }
            cout << endl;
            cout << "   ----- ----- ----- ----- ----- ----- ----- -----" << endl;
        }
    }

    // Display a screen with information about the number of Klingons
    // Starbases, and stars in the quadrants adjacent to the player.
    void printLongRangeScanner(Player player, Galaxy& galaxy)
    {
        int x = player.getQuadrantX();
        int y = player.getQuadrantY();

        cout << "Initializing long range scanner..." << endl;
        system("cls");
        cout << "Long Range Scan for Quadrant "<< x << "," << y << endl;

        // Set all scanned quadrants to 'revealed'
        for (int i = x-1; i < x+2; i++)
            for (int j = y-1; j < y+2; j++)
                if (i < XSIZE && i > -1 && j < YSIZE && j > -1)
                    galaxy.quadrantArray[i][j].setRevealed(1);


        cout << "--------------------" << endl;
        for (int i = x-1; i < x+2; i++)
        {
            cout << ": ";
            for (int j = y-1; j < y+2; j++)
            {
                if (i < 0 || i > XSIZE-1 || j < 0 || j > YSIZE-1)
                {
                    cout << "*** : ";
                }
                else
                {
                    cout << galaxy.quadrantArray[i][j].getNumEnemies();
                    cout << galaxy.quadrantArray[i][j].getNumBases();
                    cout << galaxy.quadrantArray[i][j].getNumStars();
                    cout << " : ";
                }
            }
            cout << endl;
        }
        cout << "--------------------" << endl << endl;
    }

    // Print a report of  number of Klingons, Stardates, and starbases remaining in the game.
    void printStatusReport(Galaxy galaxy, int initStardate, int currentStardate)
    {
        cout << "    Klingons Left: " << galaxy.getKlingons() << endl;
        cout << "    Mission must be completed in " << initStardate + 50 - currentStardate << " Stardates." << endl;
        cout << "    The Federation is maintaining " << galaxy.getStarbases() << " starbases in the galaxy."  << endl;

    }

    // Display a galactic map of the 16 major galactic regions and their names
    void printGalaxyMap()
    {
        cout << "                   The Galaxy                     " << endl;
        cout << "    1     2     3     4     5     6     7     8   " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 1        Antares                 Sirius          " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 2         Rigel                   Deneb          " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 3        Procyon                 Capella         " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 4         Vega                 Betelgeuse        " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 5        Canopus                Aldebaran        " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 6        Altair                  Regulus         " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 7      Sagittarius              Arcturus         " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
        cout << " 8        Pollux                   Spica          " << endl;
        cout << "  ----- ----- ----- ----- ----- ----- ----- ----- " << endl;
    }

    // Returns torpedo targeting data for all Klingons in the player's quadrant.
    void getTargetingData(Player player, Galaxy galaxy)
    {
        int qx = player.getQuadrantX();
        int qy = player.getQuadrantY();
        int sx = player.getSectorX();
        int sy = player.getSectorY();
        bool sentinel = 0;

        // Loop through entire quadrant. If an enemy is found, find out how where it is located
        // relative to the enemy, then calculate the distance to the target. If targeting data
        // is unavailable (target is not located in one of the 8 directions from the player) an
        // error is printed.
        for (int i = 0; i < XSIZE; i++)
        {
            for (int j = 0; j < YSIZE; j++)
            {
                if(galaxy.quadrantArray[qx][qy].sectorArray[i][j].hasEnemy() == 1)
                {
                  cout << "Enemy located in Sector " << i << ',' << j << endl;
                  cout << "Generating firing solution." << endl;
                  sentinel = 0;

                    //Right
                    if (i == sx && j > sy)
                    {
                        cout << "Direction: 1" << endl;
                        cout << "Distance: " << j - sy << endl;
                        sentinel = 1;
                    }

                    //Up
                    else if (i < sx && j == sy)
                    {
                        cout << "Direction: 3" << endl;
                        cout << "Distance: " << sx - i << endl;
                        sentinel = 1;
                    }

                    //Left
                    else if (i == sx && j < sy)
                    {
                        cout << "Direction: 5" << endl;
                        cout << "Distance: " << sy - j << endl;
                        sentinel = 1;
                    }

                    //Down
                    else if(i > sx && j == sy)
                    {
                        cout << "Direction: 7" << endl;
                        cout << "Distance: " << i - sx << endl;
                        sentinel = 1;
                    }

                    //Right-up
                    else if (i < sx && j > sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx - k && j == sy + k)
                            {
                                cout << "Direction: 2" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }
                    }

                    //Left-up
                    else if (i < sx && j < sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx - k && j == sy - k)
                            {
                                cout << "Direction: 4" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }

                    }


                    //Left-down
                     else if (i > sx && j < sy)
                     {
                        for (int k = 0; k < XSIZE; k++)
                         {
                            if (i == sx + k && j == sy - k)
                            {
                                cout << "Direction: 6" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                         }
                     }


                    //Right-down
                    else if (i > sx && j > sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx + k && j == sy + k)
                            {
                                cout << "Direction: 8" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }
                    }

                    if (sentinel == 0)
                        cout << "Error: Cannot lock-on to target." << endl;
                }
            }
        }
    }

    // Returns navigational data for all Starbases in the player's quadrant.
    void getStarbaseData(Player player, Galaxy galaxy)
    {
        int qx = player.getQuadrantX();
        int qy = player.getQuadrantY();
        int sx = player.getSectorX();
        int sy = player.getSectorY();
        bool sentinel = 0;

        // Loop through entire quadrant. If a starbase is found, find out how where it is located
        // relative to the player, then calculate the distance to the target. If targeting data
        // is unavailable (target is not located in one of the 8 directions from the player) an
        // error is printed.
        for (int i = 0; i < XSIZE; i++)
        {
            for (int j = 0; j < YSIZE; j++)
            {
                if(galaxy.quadrantArray[qx][qy].sectorArray[i][j].hasBase() == 1)
                {
                  cout << "Starbase located in Sector " << i << ',' << j << endl;
                  cout << "Generating navigation data." << endl;
                  sentinel = 0;

                    //Right
                    if (i == sx && j > sy)
                    {
                        cout << "Direction: 1" << endl;
                        cout << "Distance: " << j - sy << endl;
                        sentinel = 1;
                    }

                    //Up
                    else if (i < sx && j == sy)
                    {
                        cout << "Direction: 3" << endl;
                        cout << "Distance: " << sx - i << endl;
                        sentinel = 1;
                    }

                    //Left
                    else if (i == sx && j < sy)
                    {
                        cout << "Direction: 5" << endl;
                        cout << "Distance: " << sy - j << endl;
                        sentinel = 1;
                    }

                    //Down
                    else if(i > sx && j == sy)
                    {
                        cout << "Direction: 7" << endl;
                        cout << "Distance: " << i - sx << endl;
                        sentinel = 1;
                    }

                    //Right-up
                    else if (i < sx && j > sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx - k && j == sy + k)
                            {
                                cout << "Direction: 2" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }
                    }

                    //Left-up
                    else if (i < sx && j < sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx - k && j == sy - k)
                            {
                                cout << "Direction: 4" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }

                    }


                    //Left-down
                     else if (i > sx && j < sy)
                     {
                        for (int k = 0; k < XSIZE; k++)
                         {
                            if (i == sx + k && j == sy - k)
                            {
                                cout << "Direction: 6" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                         }
                     }


                    //Right-down
                    else if (i > sx && j > sy)
                    {
                        for (int k = 0; k < XSIZE; k++)
                        {
                            if (i == sx + k && j == sy + k)
                            {
                                cout << "Direction: 8" << endl;
                                cout << "Distance: " << k << endl;
                                sentinel = 1;
                            }
                        }
                    }

                    if (sentinel == 0)
                        cout << "Error: Cannot generate navigational data." << endl;
                }
            }
        }
    }

    // Display navigational data to any Sector in the Galaxy.
    void printNavData(Player player)
    {
        // Destination coordinates.
        int dQX, dQY, dSX, dSY;
        // Player coordinates.
        int pQX = player.getQuadrantX();
        int pQY = player.getQuadrantY();
        int pSX = player.getSectorX();
        int pSY = player.getSectorY();
        int direction = 0;
        int distance = 0;
        float outDistance;

        cout << "Enter Destination Quadrant X Coordinate: ";
            cin >> dQX;
        cout << "Enter Destination Quadrant Y Coordinate: ";
            cin >> dQY;
        cout << "Enter Destination Sector X Coordinate: ";
            cin >> dSX;
        cout << "Enter Destination Sector Y Coordinate: ";
            cin >> dSY;

        // Error Checking
        if (dQX < 0 || dQX > 7 || dQY < 0 || dQY > 7 || dSX < 0 || dSX > 7 || dSY < 0 || dSY > 7)
        {
            cout << "Invalid coordinate. Returning to main command." << endl;
            return;
        }

        // Right
        if ((dQX == pQX && dSX == pSX) && (dSY > pSY || dQY > pQY))
        {
            direction = 1;
            if (dQX == pQX && dQY == pQY)
                distance = dSY - pSY;
            else
                distance = (dSY - pSY) + (abs(dQY - pQY) * YSIZE);
        }
        // Up-Right
        else if ((abs(dSY - pSY) == abs(dSX - pSX)) &&
                 ((dQX < pQX && dQY > pQY) ||
                  (dQY > pQY && dSX < pSX) ||
                  (dQX < pQX && dSY > pSY) ||
                  (dQX == pQX && dQY == pQY && dSX < pSX && dSY > pSY)))
        {
            direction = 2;
            if (dQX == pQX && dQY == pQY)
                distance = pSX - dSX;
            else
                distance = (dSY - pSY) + (abs(dQY - pQY) * YSIZE);
        }
        // Up
        else if ((dQY == pQY && dSY == pSY) && (dSX > pSX || dQX > pQX))
        {
            direction = 3;
            if (dQX == pQX && dQY == pQY)
                distance = dSX - pSX;
            else
                distance = (dSX - pSX) + (abs(dQX - pQX) * XSIZE);
        }
        // Up-Left
        else if ((abs(dSY - pSY) == abs(dSX - pSX)) &&
                 ((dQX < pQX && dQY < pQY) ||
                  (dQY < pQY && dSX < pSX) ||
                  (dQX < pQX && dSY < pSY) ||
                  (dQX == pQX && dQY == pQY && dSX < pSX && dSY < pSY)))
        {
            direction = 4;
            if (dQX == pQX && dQY == pQY)
                distance = pSX - dSX;
            else
                distance = (pSY - dSY) + (abs(pQY - dQY) * YSIZE);
        }
        // Left
        else if ((dQX == pQX && dSX == pSX) && (dSY < pSY || dQY < pQY))
        {
            direction = 5;
            if (dQX == pQX && dQY == pQY)
                distance = pSY - dSY;
            else
                distance = (pSY - dSY) + (abs(pQY - dQY) * YSIZE);
        }
        // Down-Left
        else if ((abs(dSY - pSY) == abs(dSX - pSX)) &&
                 ((dQX > pQX && dQY < pQY) ||
                  (dQY < pQY && dSX > pSX) ||
                  (dQX > pQX && dSY < pSY) ||
                  (dQX == pQX && dQY == pQY && dSX > pSX && dSY < pSY)))
        {
            direction = 6;
            if (dQX == pQX && dQY == pQY)
                distance = dSX - pSX;
            else
                distance = (pSY - dSY) + (abs(pQY - dQY) * YSIZE);
        }
        // Down
        else if ((dQY == pQY && dSY == pSY) && (dSX < pSX || dQX < pQX))
        {
            direction = 7;
            if (dQX == pQX && dQY == pQY)
                distance = pSX - dSX;
            else
                distance = (pSX - dSX) + (abs(pQX - dQX) * XSIZE);
        }
        // Down-Right
        else if ((abs(dSY - pSY) == abs(dSX - pSX)) &&
                 ((dQX > pQX && dQY > pQY) ||
                  (dQY > pQY && dSX > pSX) ||
                  (dQX > pQX && dSY > pSY) ||
                  (dQX == pQX && dQY == pQY && dSX > pSX && dSY > pSY)))
        {
            direction = 8;
            if (dQX == pQX && dQY == pQY)
                distance = dSX - pSX;
            else
                distance = (dSY - pSY) + (abs(dQY - pQY) * YSIZE);
        }
        else
        {
            cout << "A Tribble ate part of the Navigation Systems. Try again with a destination " <<
                    "in one of the 8 major directions."  << endl;
            return;
        }

        if (dQX == pQX && dQY == pQY)
            outDistance = (float)distance / 10;
        else
        {
            outDistance = (float)(distance / 8);
            outDistance = outDistance + (float)(distance % 8) / 10;
        }


        cout << "Navigational Calculations for Quadrant " << dQX << "," << dQY << " Sector " << dSX << "," << dSY << " are complete." << endl;
        cout << "Direction: " << direction << endl;
        cout << "Warp Speed: " << outDistance << endl;

        return;
    }

    // Reveal all objects in the player's current Quadrant.
    void shortRangeScanner(Player player, Galaxy& galaxy, int initStardate, int currentStardate)
    {
        cout << "Initializing short range scanner..." << endl;
        system("cls");
        cout << "Short Range Scan for Quadrant "<< player.getQuadrantX() << "," << player.getQuadrantY() << endl;
        galaxy.quadrantArray[player.getQuadrantX()][player.getQuadrantY()].setRevealed(1);
        printStatusScreen(player, galaxy, initStardate, currentStardate);
    }

    // Print a map of the player's current quadrant along with an information pane.
    // Standard display screen.
    void printStatusScreen(Player player, Galaxy galaxy, int initStardate, int currentStardate)
    {
        int x = player.getQuadrantX();
        int y = player.getQuadrantY();

        // Now entering ... quadrant message.
        cout << endl << "Now entering " << translateRegion(x,y) << " quadrant..." << endl << endl;

        // Quadrant Map
        for (int i = 0; i < XSIZE; i++)
        {
            for (int j = 0; j < YSIZE; j++)
            {
                if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasBase() == 1)
                    cout << 'B';
                else if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 1 && galaxy.quadrantArray[x][y].getRevealed() == 1)
                    cout << 'E';
                else if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasEnemy() == 1 && galaxy.quadrantArray[i][j].getRevealed() == 0)
                    cout << '-';
                else if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasStar() == 1)
                    cout << '*';
                else if (galaxy.quadrantArray[x][y].sectorArray[i][j].hasPlayer() == 1)
                    cout << 'P';
                else
                    cout << '-';
            }
                // Information pane.
                if (i == 0)
                  cout << "    Stardate            " << currentStardate << endl;
                if (i == 1)
                  cout << "    Condition           " << player.getCondition() << endl;
                if (i == 2)
                  cout << "    Quadrant            " << x << "," << y << endl;
                if (i == 3)
                  cout << "    Sector              " << player.getSectorX() << "," << player.getSectorY() << endl;
                if (i == 4)
                  cout << "    Photon Torpedoes    " << player.getTorpedoes() << endl;
                if (i == 5)
                  cout << "    Total Energy        " << player.getEnergy() << endl;
                if (i == 6)
                  cout << "    Shields             " << player.getShields() << endl;
                if (i == 7)
                  cout << "    Klingons Remaining  " << galaxy.getKlingons() << endl;
        }
    }

    // Determines the player's region based on it's coordinates.
    string translateRegion(int x, int y)
    {
        string region;
        string quadrant;
        string complete;

        if (x == 0 && y < 4)
            region = "Antares";
        else if (x == 0 && y > 3)
            region = "Sirius";
        else if (x == 1 && y < 4)
            region = "Rigel";
        else if (x == 1 && y > 3)
            region = "Deneb";
        else if (x == 2 && y < 4)
            region = "Procyon";
        else if (x == 2 && y > 3)
            region = "Capella";
        else if (x == 3 && y < 4)
            region = "Vega";
        else if (x == 3 && y > 3)
            region = "Betelgeuse";
        else if (x == 4 && y < 4)
            region = "Canopus";
        else if (x == 4 && y > 3)
            region = "Aldebaran";
        else if (x == 5 && y < 4)
            region = "Altair";
        else if (x == 5 && y > 3)
            region = "Regulus";
        else if (x == 6 && y < 4)
            region = "Sagittarius";
        else if (x == 6 && y > 3)
            region = "Arcturus";
        else if (x == 7 && y < 4)
            region = "Pollus";
        else if (x == 7 && y > 3)
            region = "Spica";
        else
            region = "ERROR";

        if (y == 0 || y == 4)
            quadrant = "I";
        else if (y == 1 || y == 5)
            quadrant = "II";
        else if (y == 2 || y == 6)
            quadrant = "III";
        else if (y == 3 || y == 7)
            quadrant = "IV";

        complete = region + " " + quadrant;

        return complete;
    }
};

#endif
