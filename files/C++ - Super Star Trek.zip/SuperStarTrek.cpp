/************************************************
StarTrekMain - Star Trek text-based game.

Author: Derek Royse & Andy Pritt

Purpose: A recreation of the classic Star Trek text-based game.
*************************************************/
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <time.h>

#include "game.h"

using namespace std;

/*********************************************************************
Game begins here.
**********************************************************************/

int main()
{
    srand(time(NULL));
    Game mainGame;
    mainGame.run();
    return 0;
}
