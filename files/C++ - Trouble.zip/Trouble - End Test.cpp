// Final Project:  Trouble (end test).
// Author:         Derek Royse
// Purpose:        Recreates the boardgame Trouble.
//                 This copy starts with all players in finish order to test the
//                 goodbye screen feature (without playing an hour long game).

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <stdlib.h>

using namespace std;

  struct piece {
      char player;
      char number;
      int location;
      int startx;
      int starty;
      int startLocation;
      int finishLocation;
      int finishx;
      int finishy;
    };

//Declaration of functions
piece pieceArray[16];
void initializePieces(piece pieceArray[16]);
void Roll(char array[51][81], char player, piece pieceArray[16], int location[29][3], char homeandfinish[4][3], char helpArray[51][81]);
void printBoard(char array[51][81]);
void initializeBoard(char array[51][81]);
void initializeHelp(char array[51][81]);
void printDice(char array[51][81], int dice);
void clearDice(char array[51][81]);
void Move(char array[51][81], char player, piece pieceArray[16], int location[29][3], char homeandfinish[4][3], int dice, char pieceNumber);
void MoveFromHome(char array[51][81], char player, piece pieceArray[16], int location[28][3], char homeandfinish[4][3]);
void updatePlayers(char array[51][81], piece pieceArray[16], int location[29][3]);
void printFinal();


int main ()
{
    // Master array that holds all the board output data.
    char array[51][81];

    char helpArray[51][81];

    // Sentinel that triggers when all players are in finish.
    int ENDOFGAME = 0;

    // Player table indexed by first character representing the player's color.
    // Format: Player, pieces at home, pieces in finish.
    char homeandfinish[4][3] = {{'Y', '0', '4'},
                                {'R', '0', '4'},
                                {'G', '0', '4'},
                                {'B', '0', '4'}};

    // This table is a translation table for the board to allow easier movement of pieces.
    // This allows us to store locations as a single digit instead of 2 values.
    int location[29][3] = {{0,0,0},
                           {1,5,12},  {2,3,21},  {3,3,30},  {4,3,39},
                           {5,3,48},  {6,3,57},  {7,5,66},  {8,10,71},
                           {9,15,73}, {10,20,73},{11,25,73},{12,30,73},
                           {13,35,73},{14,40,71},{15,45,66},{16,47,57},
                           {17,47,48},{18,47,39},{19,47,30},{20,47,21},
                           {21,45,11},{22,40,6}, {23,35,4}, {24,30,4},
                           {25,25,4}, {26,20,4}, {27,15,4}, {28,10,7}};

    // Setup the board and pieces
    initializePieces(pieceArray);
    initializeBoard(array);
    initializeHelp(helpArray);


    // Print the board.
    printBoard(array);
    system("pause");

    // While the ENDOFGAME sentinel has not triggered, if statements determine
    // whether or not a player has completed the game, and if they have not, allow
    // them to roll in turn.
    while (ENDOFGAME == 0)
    {
     if (homeandfinish[0][2] != '4')
     {
        cout << "Yellow player's turn!" << endl;
        system("pause");
        Roll(array, 'Y', pieceArray, location, homeandfinish, helpArray);
     }

     if (homeandfinish[1][2] != '4')
     {
        cout << "Green player's turn!" << endl;
        system("pause");
        Roll(array, 'G', pieceArray, location, homeandfinish, helpArray);
     }
     if (homeandfinish[2][2] != '4')
     {
        cout << "Blue player's turn!" << endl;
        system("pause");
        Roll(array, 'B', pieceArray, location, homeandfinish, helpArray);
     }
     if (homeandfinish[3][2] != '4')
     {
        cout << "Red player's turn!" << endl;
        system("pause");
        Roll(array, 'R', pieceArray, location, homeandfinish, helpArray);
     }

     if (homeandfinish[0][2] == '4' && homeandfinish[1][2] == '4' && homeandfinish[2][2] == '4' && homeandfinish[3][2] == '4')
        ENDOFGAME = 1;
    }

    // Clear board and print the final screen.
    system("cls");
    printFinal();
    system("pause");

    return 0;
}

// Function rolls and decides whether a player can move, move from home, or gets no turn.
void Roll(char array[51][81], char player, piece pieceArray[16], int location[29][3], char homeandfinish[4][3], char helpArray[51][81])
{
    clearDice(array);
    system("cls");
    printBoard(array);

    char input;
    int errorCheck = 0;
    int pieceTemp = 0;
    int dice = 0;
    srand((unsigned)time(0));

    // Set 'home' equal to number of player's pieces at home.
    // Set 'finish' equal to number of player's pieces in finish.
    char home;
    char finish;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 3; j++)
            if (homeandfinish[i][j] == player)
            {
                home = homeandfinish[i][j+1];
                finish = homeandfinish[i][j+2];
            }

    // Roll the dice.
    cout << "Press any key to roll the dice!" << endl;
    system("pause");
    dice = (rand()%6)+1;
    system("cls");
    printDice(array, dice);
    printBoard(array);
    cout << "You rolled a " << dice << endl;
    system("pause");

    if (dice == 6)
    {
            while (errorCheck == 0)
            {
            cout << "You rolled a six!" << endl;
            cout << "Would you like to move a piece from home or move an existing piece?" << endl;
            cout << "Press '1' to move from home or '2' to move an existing piece." << endl;
            cout << "Press 'X' for help screen: " << endl;
                cin >> input;
            // If the player wants to move from home and has pieces in home to move.
            if (input == '1' && home > '0')
                    {
                       // Find the player's pieces.
                       for (int i = 0; i < 16; i++)
                        if (pieceArray[i].player == player)
                        {
                            // If home is not occupied, allow player to move out a piece from home.
                            if (array[location[pieceArray[i].startLocation][1]][location[pieceArray[i].startLocation][2]] == ' ')
                            {
                                MoveFromHome(array, player, pieceArray, location, homeandfinish);
                                Roll(array, player, pieceArray, location, homeandfinish, helpArray);
                                return;
                            }
                            else
                            {
                                // If no pieces are out to move, print an error message and end turn.
                                if (home == '4')
                                    {
                                        cout << "Home is occupied and no pieces are out to move." << endl;
                                        cout << "Your turn is over!" << endl;
                                        return;
                                    }
                                // If home is occupied but a piece is out, allow the player to move a piece.
                                else
                                {
                                   cout << "Home is occupied! Move an existing piece instead." << endl;
                                   goto moveChoice;
                                }

                            }
                        }
                    }
                    // If no pieces are in home to move out, print error message and allow the player to move a piece.
                    else if (input == '1' && home == '0')
                        {
                           cout << "You have no pieces left in home! Move an existing piece instead!" << endl;
                           goto moveChoice;
                        }
                    // If player decides to move an existing piece, allow them to.
                    else if (input == '2')
                            goto moveChoice;
                    // Print help screen.
                    else if (input == 'X' || input == 'x')
                        {
                            system("cls");
                            printBoard(helpArray);
                            system("pause");
                            system("cls");
                            printBoard(array);
                        }
                    else
                        {
                            cout << "Invalid choice! Try again!" << endl;
                        }
            }
    }

    else if (dice < 6)
    {
        moveChoice:
        while (errorCheck == 0)
        {
            if (home + finish == 100)
            {
                cout << "You didn't roll a six and you have no pieces on the board to move." << endl;
                cout << "Your turn is over!" << endl;
                system("pause");
                return;
            }

            else
            {
                    cout << "Which piece would you like to move " << player << "(1-4): ";
                    cin >> input;
                    for (int i = 0; i < 16; i++)
                        if (pieceArray[i].player == player && pieceArray[i].number == input)
                        {
                            // If the piece is not on the board.
                            if (pieceArray[i].location == 0 || pieceArray[i].location == 99)
                            {
                                cout << "That piece is not on the board! Try another piece!" << endl;
                            }
                            // If conditions are right, go to move function.
                            else
                            {
                                Move(array, player, pieceArray, location, homeandfinish, dice, input);
                                errorCheck = 1;
                                return;
                            }
                        }
            }
        }

    }

    return;

}

// This function determines whether a move is valid and moves the player accordingly.
void Move(char array[51][81], char player, piece pieceArray[16], int location[29][3], char homeandfinish[4][3], int dice, char pieceNumber)
{
    int x = 0;
    char targetPlayer;
    char targetPiece;
    int pieceDestination;

    for (int i = 0; i < 16; i++)
        if (pieceArray[i].player == player && pieceArray[i].number == pieceNumber)
            {
                // Assigning local variables to make things easier to keep track of.
                pieceDestination = pieceArray[i].location + dice;

                // If the move will take them past the piece past the end of the board.
                if (pieceDestination > 28)
                {
                    pieceDestination = pieceDestination - 28;
                }


                // If the player's destination is occupied by one of their own pieces
                if (array[location[pieceDestination][1]][location[pieceDestination][2]] == player)
                    {
                        cout << "Your destination is occupied by your own player!" << endl;
                        cout << "Your turn is over!" << endl;
                        return;
                    }

                // If the player's destination is occupied by another player.
                if (array[location[pieceDestination][1]][location[pieceDestination][2]] != ' '
                    && array[location[pieceDestination][1]][location[pieceDestination][2]] != player)
                {
                    // Assign the target player and piece variables.
                    targetPlayer = array[location[pieceDestination][1]][location[pieceDestination][2]];
                    targetPiece = array[location[pieceDestination][1]][location[pieceDestination][2]+1];

                    // Update the target piece data.
                    for (int j = 0; j < 16; j++)
                        if (pieceArray[j].player == targetPlayer && pieceArray[j].number == targetPiece)
                            {
                                pieceArray[j].location = 0;
                            }
                    // Update the target's home counter.
                    for (int k = 0; k < 4; k++)
                        for (int l = 0; l < 3; l++)
                            if (homeandfinish[k][l] == player)
                                homeandfinish[k][l+1]++;

                    // Put the piece back in home.
                    for (int z = 0; z < 16; z++)
                        if (pieceArray[z].player == targetPlayer && pieceArray[z].number == targetPiece)
                            {
                                array[pieceArray[z].startx][pieceArray[z].starty] = targetPiece;
                            }

                    cout << "You landed on an enemy piece! Piece " << targetPlayer << targetPiece << " was moved back to home!" << endl;
                }

                // Finally we actually move the piece.
                while (x < dice)
                {
                    // If the player is moving a character into finish.
                    if (pieceArray[i].location == pieceArray[i].finishLocation)
                        {
                            cout << "Your piece made it to the finish!";
                            pieceArray[i].location = 99;

                            updatePlayers(array, pieceArray, location);

                            // Update finish counter.
                            for (int k = 0; k < 4; k++)
                                if (homeandfinish[k][0] == player)
                                    homeandfinish[k][2]++;

                            // Draw player in finish.
                            array[pieceArray[i].finishx][pieceArray[i].finishy] = pieceNumber;
                            array[pieceArray[i].finishx][pieceArray[i].finishy - 1] = player;
                            return;
                        }

                    // Special conditions triggered to allow player to allow the board to function as a circle.
                    else if (pieceArray[i].location == 28 && player != 'Y')
                        {
                            pieceArray[i].location = 1;

                            updatePlayers(array, pieceArray, location);
                            system("pause");
                            x++;
                        }

                    // Standard move.
                    else
                    {
                        pieceArray[i].location++;
                        x++;
                        updatePlayers(array, pieceArray, location);
                        system("pause");

                    }
                }
            }
}

void MoveFromHome(char array[51][81], char player, piece pieceArray[16], int location[29][3], char homeandfinish[4][3])
{
    // Set 'home' equal to number of player's pieces at home.
    int home = 0;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 3; j++)
            if (homeandfinish[i][j] == player)
                home = homeandfinish[i][j+1];

   int pieceTemp;
   char pieceNumber;
   int errorCheck = 0;

   while (errorCheck == 0)
   {
       cout << "Please enter the piece you wish to move from home " << player << "(1 - 4): " << endl;
       cin >> pieceNumber;

        // Move the piece from home.
        for (int i = 0; i < 16; i++)
            if (pieceArray[i].player == player && pieceArray[i].number == pieceNumber)
                {
                // This erases the player from home.
                array[pieceArray[i].startx][pieceArray[i].starty] = ' ';
                array[pieceArray[i].startx][pieceArray[i].starty] = ' ';

                // This updates the player's location
                pieceArray[i].location = pieceArray[i].startLocation;

                for (int k = 0; k < 4; k++)
                    for (int j = 0; j < 3; j++)
                        if (homeandfinish[k][j] == player)
                            homeandfinish[k][j+1]--;

                // This places the character on the board.
                updatePlayers(array, pieceArray, location);
                system("pause");
                }

        return;
    }
}



// Initializes the board from troubleboard.txt
// Run only at the beginning of the program.
void initializeBoard(char array[51][81])
{
    ifstream infile;
    infile.open ("troubleboard.txt");
    infile.unsetf(ios_base::skipws);

    for (int i = 0; i < 51; i++)
    for (int j = 0; j < 81; j++)
        infile >> array[i][j];
}

// Prints the board (with piece locations) to the screen.
// Called everytime the screen is refreshed.
void printBoard(char array[51][81])
{
    for (int i = 0; i < 51; i++)
     for (int j = 0; j < 81; j++)
        if (array[i][j] != '\n')
            cout << array[i][j];
        cout << endl;
}



// This huge, ugly function simply prints ASCII art for
// the dice value in the center of the board.
void printDice(char array[51][81], int dice)
{
    switch(dice)
    {
        case 1:
            array[19][40] = '1';
            array[20][39] = '1';
            array[20][40] = '1';
            array[21][38] = '1';
            array[21][40] = '1';
            array[22][40] = '1';
            array[23][40] = '1';
            array[24][40] = '1';
            array[25][40] = '1';
            array[26][40] = '1';
            array[27][40] = '1';
            array[28][40] = '1';
            array[29][40] = '1';
            array[30][37] = '1';
            array[30][38] = '1';
            array[30][39] = '1';
            array[30][40] = '1';
            array[30][41] = '1';
            array[30][42] = '1';
            array[30][43] = '1';
            break;
        case 2:
            array[19][38] = '2';
            array[19][39] = '2';
            array[19][40] = '2';
            array[19][41] = '2';
            array[19][42] = '2';
            array[20][37] = '2';
            array[20][43] = '2';
            array[21][43] = '2';
            array[22][43] = '2';
            array[23][43] = '2';
            array[24][42] = '2';
            array[25][41] = '2';
            array[26][40] = '2';
            array[27][39] = '2';
            array[28][38] = '2';
            array[29][37] = '2';
            array[30][37] = '2';
            array[30][38] = '2';
            array[30][39] = '2';
            array[30][40] = '2';
            array[30][41] = '2';
            array[30][42] = '2';
            array[30][43] = '2';
            break;
        case 3:
            array[19][38] = '3';
            array[19][39] = '3';
            array[19][40] = '3';
            array[19][41] = '3';
            array[19][42] = '3';
            array[20][37] = '3';
            array[20][43] = '3';
            array[21][43] = '3';
            array[22][43] = '3';
            array[23][43] = '3';
            array[24][38] = '3';
            array[24][39] = '3';
            array[24][40] = '3';
            array[24][41] = '3';
            array[24][42] = '3';
            array[25][43] = '3';
            array[26][43] = '3';
            array[27][43] = '3';
            array[28][37] = '3';
            array[28][43] = '3';
            array[29][38] = '3';
            array[29][39] = '3';
            array[29][40] = '3';
            array[29][41] = '3';
            array[29][42] = '3';
            break;
        case 4:
            array[19][41] = '4';
            array[20][40] = '4';
            array[20][41] = '4';
            array[21][39] = '4';
            array[21][41] = '4';
            array[22][38] = '4';
            array[22][41] = '4';
            array[23][37] = '4';
            array[23][41] = '4';
            array[24][36] = '4';
            array[24][41] = '4';
            array[25][36] = '4';
            array[25][37] = '4';
            array[25][38] = '4';
            array[25][39] = '4';
            array[25][40] = '4';
            array[25][41] = '4';
            array[25][42] = '4';
            array[26][41] = '4';
            array[27][41] = '4';
            array[28][41] = '4';
            array[29][41] = '4';
            array[30][41] = '4';
            break;
        case 5:
            array[19][37] = '5';
            array[19][38] = '5';
            array[19][39] = '5';
            array[19][40] = '5';
            array[19][41] = '5';
            array[19][42] = '5';
            array[19][43] = '5';
            array[20][37] = '5';
            array[21][37] = '5';
            array[22][37] = '5';
            array[23][37] = '5';
            array[24][37] = '5';
            array[24][38] = '5';
            array[24][39] = '5';
            array[24][40] = '5';
            array[24][41] = '5';
            array[25][42] = '5';
            array[26][43] = '5';
            array[27][43] = '5';
            array[28][43] = '5';
            array[29][37] = '5';
            array[29][42] = '5';
            array[30][38] = '5';
            array[30][39] = '5';
            array[30][40] = '5';
            array[30][41] = '5';
            break;
        case 6:
            array[19][38] = '6';
            array[19][39] = '6';
            array[19][40] = '6';
            array[19][41] = '6';
            array[19][42] = '6';
            array[20][37] = '6';
            array[20][43] = '6';
            array[21][37] = '6';
            array[22][37] = '6';
            array[23][37] = '6';
            array[24][37] = '6';
            array[24][38] = '6';
            array[24][39] = '6';
            array[24][40] = '6';
            array[24][41] = '6';
            array[25][37] = '6';
            array[25][42] = '6';
            array[26][37] = '6';
            array[26][43] = '6';
            array[27][37] = '6';
            array[27][43] = '6';
            array[28][37] = '6';
            array[28][43] = '6';
            array[29][37] = '6';
            array[29][42] = '6';
            array[30][38] = '6';
            array[30][39] = '6';
            array[30][40] = '6';
            array[30][41] = '6';
            break;
        default:
            break;

    }
}


// This function assigns each of 16 piece structs it's player, number, location,
// home position, starting location, and final location. This array of structs also holds the location
// of the pieces, which serves as an index for the location array.
void initializePieces(piece pieceArray[16])
{
        // Yellow
        pieceArray[0].player = 'Y';
        pieceArray[0].number = '1';
        pieceArray[0].location = 0;
        pieceArray[0].startx = 4;
        pieceArray[0].starty = 2;
        pieceArray[0].startLocation = 1;
        pieceArray[0].finishLocation = 28;
        pieceArray[0].finishx = 9;
        pieceArray[0].finishy = 18;

        pieceArray[1].player = 'Y';
        pieceArray[1].number = '2';
        pieceArray[1].location = 0;
        pieceArray[1].startx = 4;
        pieceArray[1].starty = 4;
        pieceArray[1].startLocation = 1;
        pieceArray[1].finishLocation = 28;
        pieceArray[1].finishx = 9;
        pieceArray[1].finishy = 21;

        pieceArray[2].player = 'Y';
        pieceArray[2].number = '3';
        pieceArray[2].location = 0;
        pieceArray[2].startx = 4;
        pieceArray[2].starty = 6;
        pieceArray[2].startLocation = 1;
        pieceArray[2].finishLocation = 28;
        pieceArray[2].finishx = 9;
        pieceArray[2].finishy = 24;


        pieceArray[3].player = 'Y';
        pieceArray[3].number = '4';
        pieceArray[3].location = 0;
        pieceArray[3].startx = 4;
        pieceArray[3].starty = 8;
        pieceArray[3].startLocation = 1;
        pieceArray[3].finishLocation = 28;
        pieceArray[3].finishx = 9;
        pieceArray[3].finishy = 27;


        // Red
        pieceArray[4].player = 'R';
        pieceArray[4].number = '1';
        pieceArray[4].location = 0;
        pieceArray[4].startx = 47;
        pieceArray[4].starty = 2;
        pieceArray[4].startLocation = 21;
        pieceArray[4].finishLocation = 20;
        pieceArray[4].finishx = 44;
        pieceArray[4].finishy = 19;


        pieceArray[5].player = 'R';
        pieceArray[5].number = '2';
        pieceArray[5].location = 0;
        pieceArray[5].startx = 47;
        pieceArray[5].starty = 4;
        pieceArray[5].startLocation = 21;
        pieceArray[5].finishLocation = 20;
        pieceArray[5].finishx = 44;
        pieceArray[5].finishy = 22;


        pieceArray[6].player = 'R';
        pieceArray[6].number = '3';
        pieceArray[6].location = 0;
        pieceArray[6].startx = 47;
        pieceArray[6].starty = 6;
        pieceArray[6].startLocation = 21;
        pieceArray[6].finishLocation = 20;
        pieceArray[6].finishx = 44;
        pieceArray[6].finishy = 25;


        pieceArray[7].player = 'R';
        pieceArray[7].number = '4';
        pieceArray[7].location = 0;
        pieceArray[7].startx = 47;
        pieceArray[7].starty = 8;
        pieceArray[7].startLocation = 21;
        pieceArray[7].finishLocation = 20;
        pieceArray[7].finishx = 44;
        pieceArray[7].finishy = 28;


        // Green
        pieceArray[8].player = 'G';
        pieceArray[8].number = '1';
        pieceArray[8].location = 0;
        pieceArray[8].startx = 4;
        pieceArray[8].starty = 71;
        pieceArray[8].startLocation = 7;
        pieceArray[8].finishLocation = 6;
        pieceArray[8].finishx = 9;
        pieceArray[8].finishy = 50;


        pieceArray[9].player = 'G';
        pieceArray[9].number = '2';
        pieceArray[9].location = 0;
        pieceArray[9].startx = 4;
        pieceArray[9].starty = 73;
        pieceArray[9].startLocation = 7;
        pieceArray[9].finishLocation = 6;
        pieceArray[9].finishx = 9;
        pieceArray[9].finishy = 53;


        pieceArray[10].player = 'G';
        pieceArray[10].number = '3';
        pieceArray[10].location = 0;
        pieceArray[10].startx = 4;
        pieceArray[10].starty = 75;
        pieceArray[10].startLocation = 7;
        pieceArray[10].finishLocation = 6;
        pieceArray[10].finishx = 9;
        pieceArray[10].finishy = 56;


        pieceArray[11].player = 'G';
        pieceArray[11].number = '4';
        pieceArray[11].location = 0;
        pieceArray[11].startx = 4;
        pieceArray[11].starty = 77;
        pieceArray[11].startLocation = 7;
        pieceArray[11].finishLocation = 6;
        pieceArray[11].finishx = 9;
        pieceArray[11].finishy = 59;


        // Blue
        pieceArray[12].player = 'B';
        pieceArray[12].number = '1';
        pieceArray[12].location = 0;
        pieceArray[12].startx = 47;
        pieceArray[12].starty = 71;
        pieceArray[12].startLocation = 15;
        pieceArray[12].finishLocation = 14;
        pieceArray[12].finishx = 44;
        pieceArray[12].finishy = 50;


        pieceArray[13].player = 'B';
        pieceArray[13].number = '2';
        pieceArray[13].location = 0;
        pieceArray[13].startx = 47;
        pieceArray[13].starty = 73;
        pieceArray[13].startLocation = 15;
        pieceArray[13].finishLocation = 14;
        pieceArray[13].finishx = 44;
        pieceArray[13].finishy = 53;


        pieceArray[14].player = 'B';
        pieceArray[14].number = '3';
        pieceArray[14].location = 0;
        pieceArray[14].startx = 47;
        pieceArray[14].starty = 75;
        pieceArray[14].startLocation = 15;
        pieceArray[14].finishLocation = 14;
        pieceArray[14].finishx = 44;
        pieceArray[14].finishy = 56;


        pieceArray[15].player = 'B';
        pieceArray[15].number = '4';
        pieceArray[15].location = 0;
        pieceArray[15].startx = 47;
        pieceArray[15].starty = 77;
        pieceArray[15].startLocation = 15;
        pieceArray[15].finishLocation = 14;
        pieceArray[15].finishx = 44;
        pieceArray[15].finishy = 59;

}

// This function clears the dice from the array after a turn is completed.
void clearDice(char array[51][81])
{
    for (int i = 19; i < 31; i++)
        for (int j = 36; j < 44; j++)
            array[i][j] = ' ';
    return;
}

// Populates the help array.
void initializeHelp(char array[51][81])
{
    ifstream infile;
    infile.open ("helpscreen.txt");
    infile.unsetf(ios_base::skipws);

    for (int i = 0; i < 51; i++)
        for (int j = 0; j < 81; j++)
            infile >> array[i][j];
}

void updatePlayers(char array[51][81], piece pieceArray[16], int location[29][3])
{
    // Clear pieces from screen.
    for (int i = 1; i < 29; i++)
    {
        array[location[i][1]][location[i][2]] = ' ';
        array[location[i][1]][location[i][2] + 1] = ' ';
    }

    // Recreate array.
    for (int j = 0; j < 16; j++)
    {
        if (pieceArray[j].location != 0 && pieceArray[j].location != 99)
        {
            array[location[pieceArray[j].location][1]][location[pieceArray[j].location][2]] = pieceArray[j].player;
            array[location[pieceArray[j].location][1]][location[pieceArray[j].location][2]+1] = pieceArray[j].number;
        }
    }

    system("cls");
    printBoard(array);
    return;
}

// Function to print a goodbye screen.
void printFinal()
{
    char array[51][81];
    ifstream infile;
    infile.open ("finishscreen.txt");
    infile.unsetf(ios_base::skipws);

    for (int i = 0; i < 51; i++)
        for (int j = 0; j < 81; j++)
        {
        infile >> array[i][j];
        if (array[i][j] != '\n')
            cout << array[i][j];
        }
    cout << endl;
}
